#coding=utf-8

## Copyright (c) 2019 Vít Baisa

import sys
import re
import corplib
import json as jsonlib


LTR = '\xe2\x80\x8e'
RTL = '\xe2\x80\x8f'
cgi_publisher = None

trend_dict = {2: 'sharp increase',
              1: 'increase',
              0: 'steady',
              -1: 'decrease',
              -2: 'sharp decrease'}

def scoll(o):
    if o.get('coll'):
        return f'<coll>' + o.get('str', o.get('strc', '')) + o.get('attr', '') + f'</coll>'
    else:
        return o.get('str', o.get('strc', '')) + o.get('attr', '')

def s(o):
    return o.get('str', o.get('strc', '')) + o.get('attr', '')

def n(s):
    return s.replace('&', '&amp;').replace('<', '&lt;')\
            .replace('>', '&gt;').replace('"', '&quot;').replace('  ', ' ')

def nt(s):
    return s.replace('&', '&amp;').replace('<', '&lt;') \
        .replace('>', '&gt;').replace('"', '&quot;').replace('  ', ' ').replace('\t', ' ')

def c(s):
    return s.replace('"', '""').replace("'", "''").replace('  ', ' ')

def ct(s):
    s = s.replace('\xa0', ' ').replace('\t', ' ').replace('"', '""')
    if s.startswith("'"):
        s = "'" + s
    return s

def t(s):
    return s.replace('  ', ' ').replace('\t', '\v')

def double_spaces(s):
    return s.replace('  ', ' ')

def double_spaces_tab(s):
    return s.replace('  ', ' ').replace('\t', ' ')

def get_attr_name(attr, methodname=None):
    attr_map = {
        'aldf': 'ALDF',
        'aldf1': 'ALDF (focus)',
        'aldf2': 'ALDF (reference)',
        'arf': 'ARF',
        'arf1': 'ARF (focus)',
        'arf2': 'ARF (reference)',
        'docf': 'DOCF',
        'docf1': 'DOCF (focus)',
        'docf2': 'DOCF (reference)',
        'gdex_examples': 'Example',
        'fpm': 'Freq. per million',
        'freq': 'Frequency',
        'frq': 'Frequency',
        'frq1': 'Frequency (focus)',
        'frq2': 'Frequency (reference)',
        'item': 'Item',
        'poc': '% of concordance',
        'rel': 'Relative frequency',
        'reltt': 'Relative in text types',
        'rel_docf1': 'Relative DOCF (focus)',
        'rel_docf2': 'Relative DOCF (reference',
        'rel_frq1': 'Relative frequency (focus)',
        'rel_frq2': 'Relative frequency (reference)',
        'reldocf': 'Relative DOCF',
        'relfreq': 'Relative frequency',
        'rnk:f': 'Rating',
        'score': 'Score',
        'star:f': 'Rating',
        'star1': 'Rating',
        'star2': 'Rating',
        'str': 'Item',
        'token:l': 'Tokens',
        'freqs___rel': 'Relative density',
        'freqml___rel': 'Relative density',
        'norm:l': 'Words',
        'example': 'Example',
        'hwd': 'Headword',
        'rel': 'Relation',
        'col': 'Collocation',
    }
    if methodname and methodname + '___' + attr in attr_map:
        return attr_map[methodname + '___' + attr]
    if attr in attr_map:
        return attr_map[attr]
    else:
        return attr

def get_attr_formatted_value(attr, value, escape_function=None, format=None):
    if attr.endswith('1') or attr.endswith('2'):
        attr = attr[:-1]
    if attr in ['biterms_examples', 'item', 'str', 'ws_colloc']:
        if format == 'xlsx':
            return '%s' % (escape_function(value) if escape_function else value)
        else:
            return '"%s"' % (escape_function(value) if escape_function else value)
    elif attr in ['gdex_examples']:
        if value:
            gdex_examples = []
            for sent, label in value:
                if format == 'xlsx':
                    gdex_examples.append('%s <%s>' % (sent, label))
                else:
                    gdex_examples.append('"%s <%s>"' % (re.sub('"', '""', sent), label))
            return gdex_examples
        else:
            return 'None'
    elif attr in ['docf', 'freq', 'frq', 'norm:l', 'token:l']:
        return '%d' % int(value or '0')
    elif attr in ['aldf', 'arf', 'fpm', 'poc', 'relfreq', 'rel_frq', 'reldocf', 'rel_docf', 'rel', 'reltt']:
        return '%.5f' % float(value or '0.0')
    elif attr in ['rnk', 'rnk:f', 'score']:
        return '%.3f' % float(value or '0.0')
    elif attr in ['star', 'star:f']:
        return '%.2f' % float(value or '0.0')


def get_frq_attrs(data):
    all_attrs = []
    for attr in data["FCrit"]:
        all_attrs += re.findall('([^ ]+)/.*?', attr['fcrit'])

    # raise Exception(f'{all_attrs}\n{data["ref_list"]}')
    if not False in [x in data['ref_list'] for x in all_attrs]:
        return ['frq', 'rel', 'reltt', 'example']
    else:
        if int(data['concsize']) < int(data['fullsize']):
            return ['frq', 'poc', 'example']
        else:
            return ['frq', 'fpm', 'poc', 'example']


def txt(methodname, data, outf, nl, params):
    export_note = params.get('export_note', '')
    if export_note:
        outf.write(export_note + nl + nl)
    outf.write('corpus: %s' % t(params.get('corpname', '')) + nl)
    outf.write('subcorpus: %s' % t(params.get('usesubcorp', '-')) + nl)
    if data.get('concsize', False):
        outf.write('size: %d' % int(data['concsize']) + nl)
    if (data.get('Desc', '')):
        outf.write('query: %s' % ', '.join([t(d.get('op', 'operation')) + ':'\
                + t(d.get('arg', 'argument')) for d in data['Desc']]) + nl)
    if 'error' in data:
        outf.write('An error occurred, check results in UI or in JSON format.' + nl)
        outf.write('"Error: %s"' % data['error'] + nl)
        return
    if methodname == 'concordance':
        def printl(l):
            if params.get('annotconc'):
                linegroup =  l['linegroup'] if l.get('linegroup', '_') != '_' else ''
                outf.write("#%s " % linegroup)
            if params.get('refs'):
                outf.write('%s | ' % t(','.join(l.get('Refs', []))))
            outf.write(' '.join([t(scoll(x)) for x in l['Left']]) + ' ')
            if params.get('sepkwic', False):
                outf.write('<<<')
            outf.write(' '.join([t(scoll(x)) for x in l['Kwic']]))
            if params.get('sepkwic', False):
                outf.write('>>>')
            outf.write(' ')
            outf.write(' '.join([t(scoll(x)) for x in l['Right']]) + ' ')
            if data.get('gdex_scores', False):
                gdex_sore = "{:.5f}".format(data['gdex_scores'][l['toknum']])
                outf.write(' | {}'.format(gdex_sore))

        if params.get('annotconc'):
            outf.write('Label,')
        if params.get('refs'):
            outf.write('Reference,')
        outf.write('Sentence')
        if data.get('gdex_scores', False):
            outf.write(',GDEX score')
        outf.write(nl)
        for line in data['Lines']:
            printl(line)
            if line.get('Align', []):
                outf.write('\t')
                for j, al in enumerate(line['Align']):
                    printl(al)
            outf.write(nl)

    elif methodname.startswith('freq') or methodname == 'struct_wordlist':
        all_attrs = get_frq_attrs(data)
        for block in data['Blocks']:
            items = block['Items']
            if block.get('blockname', ''):
                outf.write('%s:' % block['blockname'] + nl)
                outf.write('-------' + nl)
            if items:
                attr_list = list(filter(lambda attr: attr in items[0], all_attrs))
                head_list = [h['n'] for h in block['Head'] if 'id' in h] + [get_attr_name(attr, methodname) for attr in attr_list]
                outf.write(','.join(head_list) + nl)
                for item in items:
                    for w in item['Word']:
                        outf.write('%s, ' % t(w['n']))
                    outf.write(', '.join([get_attr_formatted_value(attr, item[attr], t) for attr in attr_list]) + nl)

    elif methodname.startswith('coll'):
        for item in data['Items']:
            outf.write('%s	%d %d ' % (c(item['str']),
                    int(item['freq']), int(item['coll_freq'])))
            outf.write(' '.join(['%.5f' % float(x['s'])\
                    for x in item['Stats']]))
            outf.write(nl)
    else:
        outf.write("Method %s doesn't support export to TXT." % methodname + nl)

def tmx(methodname, data, outf, nl, params):
    corpname = params.get('corpname')
    prefix = '/'.join(corpname.split('/')[:-1]) + '/' if '/' in corpname else ''
    corpname_list = [prefix + c for c in params.get('concordance_query')[0]['sel_aligned']] + [corpname]
    cm = corplib.CorpusManager([corpname_list], abs_corpname=cgi_publisher.abs_corpname)
    languages = [cm.get_Corpus(c).get_conf('LANGUAGE') for c in corpname_list]
    export_note = params.get('export_note', '')

    outf.write("<?xml version='1.0' encoding='UTF-8' ?>" + nl)
    outf.write('<tmx version="1.0">' + nl)
    outf.write('  <header creationtool="Sketch Engine" segtype="sentence"')
    outf.write(' datatype="plaintext" srclang="%s">' % languages[-1] + nl)
    if export_note:
        outf.write('    <note>%s</note>' % n(export_note) + nl)
    outf.write('  </header>' + nl)
    outf.write('  <body>' + nl)
    if 'error' in data:
        outf.write('    <error>An error occurred, check results in UI or in JSON format.</error>' + nl)
        outf.write('    <error>%s</error>' % data['error'] + nl)
        outf.write('</body></tmx>' + nl)
        return
    if methodname == 'concordance':
        def printl(l, language):
            outf.write('      <tuv lang="%s">' % language + nl)
            outf.write('        <seg>')
            outf.write(' '.join([n(s(x)) for x in l['Left']]) + ' ')
            outf.write(' '.join([n(s(x)) for x in l['Kwic']]) + ' ')
            outf.write(' '.join([n(s(x)) for x in l['Right']]))
            outf.write('</seg>' + nl)
            outf.write('      </tuv>' + nl)
        for line in data['Lines']:
            outf.write('    <tu>' + nl)
            printl(line, languages[-1])
            if line.get('Align', []):
                outf.write('')
                for j, al in enumerate(line['Align']):
                    printl(al, languages[j])
            outf.write('    </tu>' + nl)
    else:
        outf.write('    <tu><tuv lang="en">')
        outf.write('<seg>Method %s does not support export to TMX.' % methodname)
        outf.write('</seg></tuv></tu>' + nl)
    outf.write('  </body>' + nl)
    outf.write('</tmx>' + nl)

def csv(methodname, data, outf, nl, params):
    outf.write('\ufeff')
    export_note = params.get('export_note', '')
    if export_note:
        outf.write('"%s"' % c(export_note) + nl + nl)
    outf.write('"corpus","%s"' % c(params.get('corpname', '')) + nl)
    outf.write('"subcorpus","%s"' % c(params.get('usesubcorp', '-')) + nl)
    if data.get('concsize', False):
        outf.write('"concordance size","%d"' % int(data['concsize']) + nl)
    if (data.get('Desc', '')):
        outf.write('"query","%s"' % ';'.join(
                [c(d.get('op', 'operation')) + ':' + c(d.get('arg', 'argument'))\
                for d in data['Desc']]) + nl)
    if 'error' in data:
        outf.write('"An error occurred, check results in UI or in JSON format."' + nl)
        outf.write('"Error: %s"' % data['error'] + nl)
        return

    if methodname == 'biterms':
        showfrq = int(params.get('showfrq', "0"))
        showkeyness = int(params.get('showkeyness', "0"))
        showlogdice = int(params.get('showlogdice', "0"))
        examples_no = int(params.get("examples_no", "0"))
        columns = [
            ['Source term', lambda row: c(row[0]),                      True],
            ['L1 freq',     lambda row: f'{int(row[3])}',               showfrq],
            ['Keyness',     lambda row: f'{int(row[5])}',               showkeyness],
            ['Target term', lambda row: c(row[1]),                      True],
            ['L2 freq',     lambda row: f'{int(row[4])}',               showfrq],
            ['Co-freq',     lambda row: f'{int(row[2])}',               showfrq],
            ['LogDice',     lambda row: '{:.3f}'.format(float(row[7])), showlogdice]
        ]
        head_list = [f'"{col[0]}"' for col in columns if col[2]]
        if examples_no:
            for i in range(1, examples_no + 1):
                head_list.append(f'"{get_attr_name("example")} {i} ({corp_name_l1.split("/")[-1]})"')
                head_list.append(f'"{get_attr_name("example")} {i} ({corp_name_l2})"')
        outf.write(','.join(head_list) + nl)
        for item in data['Biterms']:
            for row in data['BitermsDict'][item]:
                value_list = [col[1](row) for col in columns if col[2]]
                if examples_no:
                    for x in row[10]:
                        value_list += get_attr_formatted_value('biterms_examples', x[0], ct, 'csv')
                        value_list += get_attr_formatted_value('biterms_examples', x[1], ct, 'csv')
                outf.write(','.join(value_list) + nl)

    elif methodname == 'wsketch':
        if not int(params.get('structured', True)):
            outf.write('Keyword,Gramrel,Collocate,Freq,Score' + nl)
            for item in data['Items']:
                nicename = c(item['gramrel'].replace('"%w"', 'X').replace('%w', 'X'))
                outf.write('{},"{}",{},{},{:.3f}'.format(data.get('lemma', ''), nicename,
                                                       item.get('word', ''),
                                                       item.get('count', 0),
                                                       float(item['score'] or '0.0') or 0.0))
                outf.write(nl)
        else:
            outf.write('Keyword,Gramrel,Collocate,Freq,Score' + nl)
            for gr in data['Gramrels']:
                nicename = c(gr['name'].replace('"%w"', 'X').replace('%w', 'X'))
                outf.write('{},"{}",,{},{:.3f}'.format(data.get('lemma', ''), nicename, gr.get('count', 0),
                                                       float(gr['score'] or '0.0') or 0.0))
                outf.write(nl)
                for w in gr['Words']:
                    outf.write(',,"%s",%d,%.3f' %\
                            (c(w.get('word', w.get('name', ''))),
                            int(w['count']), float(w['score'])))
                    outf.write(nl)

    elif methodname.startswith('coll'):
        for item in data['Items']:
            outf.write('"%s",%d,%d,' % (c(item['str']),
                    int(item['freq']), int(item['coll_freq'])))
            outf.write(','.join(['%.5f' % float(x['s'])\
                    for x in item['Stats']]))
            outf.write(nl)

    elif methodname == 'concordance':
        def printl(l):
            delimiter = '","' if params.get('viewmode') == 'kwic' else ' '
            if params.get('annotconc'):
                linegroup = l['linegroup'] if l.get('linegroup', '_') != '_' else ''
                outf.write('"' + t(linegroup) + '",')
            if data.get('righttoleft', False):
                l['Left'], l['Right'] = l['Right'], l['Left']
            outf.write('"%s",' % c(','.join(line.get('Refs', []))))
            if data.get('righttoleft', False):
                outf.write(RTL)
            outf.write('"' + ' '.join([c(scoll(x)) for x in l['Left']]))
            outf.write(delimiter)
            outf.write(' '.join([c(s(x)) for x in l['Kwic']]))
            outf.write(delimiter)
            outf.write(' '.join([c(scoll(x)) for x in l['Right']]) + '"')
            if data.get('righttoleft', False):
                outf.write(LTR)
            if data.get('gdex_scores', False):
                gdex_score = "{:.5f}".format(data['gdex_scores'][l['toknum']])
                outf.write(',"{}"'.format(gdex_score))

        if params.get('annotconc'):
            outf.write('"Label",')
        if params.get('viewmode') == 'kwic':
            outf.write('"Reference","Left","KWIC","Right"')
            if data.get('gdex_scores', False):
                outf.write(',"GDEX score"')
            outf.write(nl)
        else:
            outf.write('"Reference","Sentence"')
            if data.get('gdex_scores', False):
                outf.write(',"GDEX score"')
            outf.write(nl)

        for line in data['Lines']:
            printl(line)
            if line.get('Align', []):
                outf.write(',')
                for j, al in enumerate(line['Align']):
                    printl(al)
            outf.write(nl)

    elif methodname.startswith('freq') or methodname == 'struct_wordlist':
        all_attrs = get_frq_attrs(data)
        for block in data['Blocks']:
            items = block['Items']
            if block.get('blockname', ''):
                outf.write('BLOCK %s:' % block['blockname'] + nl)
            if items:
                attr_list = list(filter(lambda attr: attr in items[0], all_attrs))
                head_list = [h['n'] for h in block['Head'] if 'id' in h] + [get_attr_name(attr, methodname) for attr in attr_list]
                outf.write(', '.join(['"%s"' % attr for attr in head_list]) + nl)
                for item in items:
                    for w in item['Word']:
                        outf.write('"%s",' % c(w['n']))
                    outf.write(', '.join([get_attr_formatted_value(attr, item[attr], t) for attr in attr_list]) + nl)

    elif methodname == 'thes':
        outf.write('"%s",%d,"%s"' %\
                (c(params.get('lemma', '')), params.get('freq', 0),
                c(params.get('lpos', ''))) + nl)
        for w in data['Words']:
            outf.write('"%s",%.3f,%d' %\
                    (c(w['word']), w['score'], w['freq']) + nl)
            for cl in w.get('Clust', []):
                outf.write(',"%s",%.3f,%d' %\
                        (c(cl['word']), cl['score'], cl['freq']) + nl)

    elif methodname in ['wordlist', 'poswordlist']:
        items = data.get('Items', [])
        all_attrs = ['str', 'frq', 'relfreq', 'docf', 'reldocf', 'arf', 'aldf', 'star:f', 'rnk:f', 'norm:l', 'token:l']
        usengrams = params.get('usengrams', 0)
        nest_ngrams = params.get('nest_ngrams', 0)

        def print_line(item, level=0):
            if params.get('wlattr') == 'WSCOLLOC': # wordlist from collocations
                hwd, rel, col = item['str'].split('\t')[:3]
                value_list = [get_attr_formatted_value('str', hwd, ct),
                              get_attr_formatted_value('str', rel, ct),
                              get_attr_formatted_value('str', col, ct)]
            else:
                value_list = [get_attr_formatted_value('str', item['str'], ct)]
            value_list += [get_attr_formatted_value(attr, item[attr], ct) for attr in attr_list]
            value_list[0] = '—' * level + value_list[0]
            outf.write(','.join(value_list) + nl)

        def nested(ngram, level=0):
            if level:
                print_line(ngram, level)
            for ch in ngram.get('children', []):
                nested(ch, level+1)

        if items:
            attrs = [params.get('wlsort')]  \
                + params.get('wlnums', '').split(',')  \
                + (['relfreq'] if params.get('relfreq', False) else [])  \
                + (['reldocf'] if params.get('reldocf', False) else [])

            attr_list = list(filter(lambda attr: attr in attrs and attr in items[0], all_attrs))

            if params.get('wlattr') == 'WSCOLLOC': # wordlist from collocations
                outf.write(','.join([get_attr_name(attr) for attr in ['hwd', 'rel', 'col'] + attr_list]) + nl)
            else:
                outf.write(','.join([get_attr_name(attr) for attr in ['str'] + attr_list]) + nl)

            for i in data['Items']:
                print_line(i)
                if usengrams == 1 and nest_ngrams == 1 and i.get('children', []):
                    nested(i)

    elif methodname == 'wsdiff':
        outf.write('"%s","%s"' % (c(data['lbl1']), c(data['lbl2'])) + nl)
        outf.write('"coll","freq1","freq2","score1","score2","color"' + nl)
        for gr in data['content']['common']:
            h = gr['table']['Header']
            outf.write('"RELATION %s",%s,%s,%s,%s,_' % (c(h[0]),
                    h[1], h[2], h[3], h[4]) + nl)
            for r in gr['table']['Rows']:
                outf.write('"%s",%s,%s,%s,%s,%s' % (c(r['word']),
                        r['cnt1'], r['cnt2'], r['rnk1'] or '--', r['rnk2'] or '--',
                        r['class']) + nl)

    elif methodname in ['extract_keywords', 'wipo']:
        items = data.get('keywords')
        all_attrs = ['item', 'frq1', 'frq2', 'rel_frq1', 'rel_frq2', 'docf1', 'docf2', 'rel_docf1', 'rel_docf2', 'arf1',
                     'arf2', 'aldf1', 'aldf2', 'star1', 'star2', 'score', 'gdex_examples']
        if items:
            attr_list = list(filter(lambda attr: attr in items[0], all_attrs))
            head_list = []
            for attr in attr_list:
                if attr != 'gdex_examples':
                    head_list.append(get_attr_name(attr))
                else:
                    head_list += [f'{get_attr_name("gdex_examples")} {i}' for i in range(1, int(params["examples_no"])+1)]

            outf.write(','.join(head_list) + nl)
            for item in items:
                value_list = []
                for attr in attr_list:
                    if attr == 'gdex_examples':
                        value_list += get_attr_formatted_value(attr, item[attr], ct, 'csv')
                    else:
                        value_list.append(get_attr_formatted_value(attr, item[attr], ct, 'csv'))
                outf.write(','.join(value_list) + nl)

    elif methodname == 'trends':
        # dict results = [_id, w, trend, p, f, simple_trend]
        outf.write('Item{},Trend,P-value (degree of change),Frequency,Simple trend,Simple trend number'.format(f' ({params.get("trends_attr")})' if params.get("trends_attr", None) else "") + nl)
        for _id, w, trend, p, f, simple_trend in data['result']:
            outf.write(f'{c(w)},{trend},{"{:.20f}".format(p).rstrip("0").rstrip(".")},{f},{trend_dict[int(simple_trend)]}, {simple_trend}' + nl)

    else:
        outf.write('Method %s does not support export to CSV.' %\
                methodname + nl)


def xlsx(methodname, data, outf, nl, params):
    import openpyxl
    import re
    from io import BytesIO
    illegal_character_re = re.compile(r'[\000-\010]|[\013-\014]|[\016-\037]')
    control_characters = re.compile('^[+\-@=].*')

    def correct_content(data):
        """
        Remove unsupported Excel characters and add white space at the beginning of string to
        prevent Excel to expand math functions
        :param data: str
        :return: str
        """
        result = illegal_character_re.sub('', data)
        if control_characters.match(data):
            return f' {result}'
        else:
            return result

    wb = openpyxl.Workbook()
    virtual_file = BytesIO()

    ws1 = wb.active
    ws1.title = methodname

    content = []

    export_note = params.get('export_note', '')
    if export_note:
        ws1.append([c(export_note)])
    # Corpus info
    ws1.append([f'method name: {methodname}'])
    ws1.append([f'corpus: {c(params.get("corpname", ""))}'])
    ws1.append([f'subcorpus: {c(params.get("usesubcorp", "-"))}'])
    if data.get('concsize', False):
        ws1.append([f'concordance size: {int(data["concsize"])}'])
    if (data.get('Desc', '')):
        ws1.append(['query: {}'.format(';'.join(
            [c(d.get('op', 'operation')) + ':' + c(d.get('arg', 'argument')) \
             for d in data['Desc']]))])

    if 'error' in data:
        ws1.append(['An error occurred, check results in UI or in JSON format.'])
        ws1.append(['Error: {}'.format(data['error'])])
        wb.save(virtual_file)
        outf.buffer.write(virtual_file.getvalue())
        return

    if methodname == 'biterms':
        showfrq = int(params.get('showfrq', '0'))
        showkeyness = int(params.get('showkeyness', '0'))
        showlogdice = int(params.get('showlogdice', '0'))
        examples_no = int(params.get("examples_no", "0"))
        columns = [
            ['Source term', lambda row: c(row[0]),                      True],
            ['L1 freq',     lambda row: f'{int(row[3])}',               showfrq],
            ['Keyness',     lambda row: f'{int(row[5])}',               showkeyness],
            ['Target term', lambda row: c(row[1]),                      True],
            ['L2 freq',     lambda row: f'{int(row[4])}',               showfrq],
            ['Co-freq',     lambda row: f'{int(row[2])}',               showfrq],
            ['LogDice',     lambda row: '{:.3f}'.format(float(row[7])), showlogdice]
        ]
        head_list = [f'"{col[0]}"' for col in columns if col[2]]
        if examples_no:
            for i in range(1, examples_no + 1):
                head_list.append(f'"{get_attr_name("example")} {i} ({corp_name_l1.split("/")[-1]})"')
        content.append(head_list)
        for item in data['Biterms']:
            for row in data['BitermsDict'][item]:
                value_list = [col[1](row) for col in columns if col[2]]
                if examples_no:
                    for x in row[10]:
                        value_list += get_attr_formatted_value('biterms_examples', x[0], ct, 'csv')
                        value_list += get_attr_formatted_value('biterms_examples', x[1], ct, 'csv')
                content.append(value_list)

    elif methodname == 'extract_keywords':
        items = data.get('keywords')
        all_attrs = ['item', 'frq1', 'frq2', 'rel_frq1', 'rel_frq2', 'docf1', 'docf2', 'rel_docf1', 'rel_docf2', 'arf1',
                     'arf2', 'aldf1', 'aldf2', 'star1', 'star2', 'score', 'gdex_examples']
        if items:
            attr_list = list(filter(lambda attr: attr in items[0], all_attrs))
            head_list = []
            for attr in attr_list:
                if attr != 'gdex_examples':
                    head_list.append(get_attr_name(attr))
                else:
                    head_list += [f'{get_attr_name("gdex_examples")} {i}' for i in range(1, int(params["examples_no"])+1)]

            content.append(head_list)
            for item in items:
                value_list = []
                for attr in attr_list:
                    if attr == 'gdex_examples':
                        value_list += get_attr_formatted_value(attr, item[attr], ct, 'xlsx')
                    else:
                        value_list.append(get_attr_formatted_value(attr, item[attr], ct, 'xlsx'))
                # value_list = [get_attr_formatted_value(attr, item[attr], nt, format='xlsx') for attr in attr_list]
                content.append(value_list)

    elif methodname == 'wsketch':
        if not int(params.get('structured', True)):
            head_list = ['Keyword', 'Gramrel', 'Collocate', 'Freq', 'Score']
            content.append(head_list)
            for item in data['Items']:
                nicename = item['gramrel'].replace('"%w"', 'X').replace('%w', 'X')
                value_list = [data['lemma'], nicename, item.get('word', ''), item.get('count', 0),
                              '{:.3g}'.format(float(item['score'] or '0.0') or 0.0)]
                content.append(value_list)
        else:
            head_list = ['Keyword', 'Gramrel', 'Collocate', 'Freq', 'Score']
            content.append(head_list)
            for gr in data['Gramrels']:
                nicename = gr['name'].replace('"%w"', 'X').replace('%w', 'X')
                value_list_1 = [data['lemma'], nicename, '', gr.get('count', 0),
                                '{:.3g}'.format(float(gr['score'] or '0.0') or 0.0)]
                content.append(value_list_1)
                for w in gr['Words']:
                    value_list = ['', '', w.get('word', w.get('name', '')), w['count'],
                                    '{:.3f}'.format(w['score'])]
                    content.append(value_list)

    elif methodname.startswith('coll'):
        mldict = {x['s']:x['n'] for x in data['Head'] if 's' in x}
        head_list = ['Collocate', 'Freq', 'Coll. freq.']
        for x in data['Items'][0]['Stats']:
            head_list.append(mldict.get(x['n'], ''))
        content.append(head_list)
        for item in data['Items']:
            value_list = [item['str'], int(item['freq']), int(item['coll_freq'])]
            for x in item['Stats']:
                value_list.append('{:.5f}'.format(float(x['s'])))
            content.append(value_list)

    elif methodname == 'concordance':
        def printl(l):
            value_list = []
            if params.get('annotconc'):
                linegroup = l['linegroup'] if l.get('linegroup', '_') != '_' else ''
                value_list.append(linegroup)
            value_list.append(','.join(l.get('Refs', [])))
            left = ' '.join([scoll(x) for x in l['Left']])
            kwic = ' '.join([s(x) for x in l['Kwic']])
            right = ' '.join([scoll(x) for x in l['Right']])

            # View mode
            if params.get('viewmode') == 'kwic':
                value_list += [left, kwic, right]
            else:
                value_list.append('{} {} {}'.format(left, kwic, right))

            if data.get('gdex_scores', False):
                gdex_sore = "{:.5f}".format(data['gdex_scores'][l['toknum']])
                value_list.append(gdex_sore)

            return value_list

        head_list = []
        if params.get('annotconc'):
            head_list.append('Label')
        head_list.append('Reference')
        if params.get('viewmode') == 'kwic':
            head_list += ['Left', 'Kwic', 'Right']
            if data.get('gdex_scores', False):
                head_list.append('GDEX score')
        else:
            head_list.append('Sentence')
            if data.get('gdex_scores', False):
                head_list.append('GDEX score')
        content.append(head_list)

        for i, line in enumerate(data['Lines']):
            if line.get('Align', []):
                value_list = printl(line)
                for j, al in enumerate(line['Align']):
                    value_list += printl(al)
            else:
                value_list = printl(line)
            content.append(value_list)

    elif methodname.startswith('freq') or methodname == 'struct_wordlist':
        all_attrs = get_frq_attrs(data)
        for block in data['Blocks']:
            items = block['Items']
            if block.get('blockname', ''):
                content.append(block['blockname'])
            if items:
                attr_list = list(filter(lambda attr: attr in items[0], all_attrs))
                head_list = [h['n'] for h in block['Head'] if 'id' in h] + [get_attr_name(attr, methodname) for attr in attr_list]

                content.append(head_list)
                for item in items:
                    value_list = []
                    for i, w in enumerate(item['Word']):
                        value_list.append(w['n'])
                    value_list += [get_attr_formatted_value(attr, item[attr], t, format='xlsx') for attr in attr_list]
                    content.append(value_list)

    elif methodname == 'thes':
        head_list = ['Input lemma', 'Thesaurus result', 'Score', 'Freq']
        content.append(head_list)
        for w in data['Words']:
            content.append([w['word'], w['word'], '{:.3f}'.format(w['score']), int(w['freq'])])
            for cl in w.get('Clust', []):
                content.append(['', cl['word'], '{:.3f}'.format(cl['score']), int(cl['freq'])])

    elif methodname in ['wordlist', 'poswordlist']:
        items = data.get('Items', [])
        all_attrs = ['str', 'frq', 'relfreq', 'docf', 'reldocf', 'arf', 'aldf', 'star:f', 'rnk:f', 'norm:l', 'token:l']
        usengrams = params.get('usengrams', "0")
        nest_ngrams = params.get('nest_ngrams', "0")

        def print_line(item, workbook=None, level=0):
            if params.get('wlattr') == 'WSCOLLOC': # wordlist from collocations
                hwd, rel, col = item['str'].split('\t')[:3]
                value_list = [get_attr_formatted_value('str', hwd, double_spaces_tab, format='xlsx'),
                              get_attr_formatted_value('str', rel, double_spaces_tab, format='xlsx'),
                              get_attr_formatted_value('str', col, double_spaces_tab, format='xlsx')]
            else:
                value_list = [get_attr_formatted_value('str', item['str'], double_spaces_tab, format='xlsx')]
            value_list += [get_attr_formatted_value(attr, item[attr], double_spaces_tab, format='xlsx') for attr in attr_list]
            value_list[0] = '—' * level + value_list[0]
            workbook.append(value_list)

        def nested(ngram, level=0):
            if level:
                print_line(ngram, workbook=content, level=level)
            for ch in ngram.get('children', []):
                nested(ch, level+1)

        if items:
            attrs = [params.get('wlsort')]  \
                + params.get('wlnums', '').split(',')  \
                + (['relfreq'] if params.get('relfreq', False) else [])  \
                + (['reldocf'] if params.get('reldocf', False) else [])

            attr_list = list(filter(lambda attr: attr in attrs and attr in items[0], all_attrs))

            if params.get('wlattr') == 'WSCOLLOC': # wordlist from collocations
                content.append([get_attr_name(attr) for attr in ['hwd', 'rel', 'col'] + attr_list])
            else:
                content.append([get_attr_name(attr) for attr in ['str'] + attr_list])
            for i in data['Items']:
                print_line(i, content)
                if usengrams == 1 and nest_ngrams == 1 and i.get('children', []):
                    nested(i)

    elif methodname == 'wsdiff':
        head_list = ['Collocate', 'Freq1', 'Freq2', 'Score1', 'Score2', 'Color']
        content.append(head_list)
        for gr in data['content']['common']:
            h = gr['table']['Header']
            value_list = [h[0], int(h[1]), int(h[2]), '{:.3f}'.format(float(h[3])), '{:.3f}'.format(float(h[4])), '']
            content.append(value_list)
            for r in gr['table']['Rows']:
                value_list = [r['word'], int(r['cnt1']), int(r['cnt2']), r['rnk1'] or '--', r['rnk2'] or '--', r['class']]
                content.append(value_list)
    elif methodname == 'trends':
        # dict results = [_id, w, trend, p, f, simple_trend]
        head_list = [f'Item' + f' ({params.get("trends_attr")})' if params.get("trends_attr", None) else "",
                     'Trend', 'P-value (degree of change)', 'Frequency', 'Simple trend', 'Simple trend number']
        content.append(head_list)
        for _id, w, trend, p, f, simple_trend in data['result']:
            value_list = [c(w), trend, "{:.20f}".format(p).rstrip("0").rstrip("."), f, trend_dict[int(simple_trend)],
                          simple_trend]
            content.append(value_list)
    else:
        content.append(['Method {} does not support export to XLSX.'.format(methodname)])

    for row in content:
        # try add line to worksheet by correcting the content - if error raises remove all content and print Error
        corrected_row = []
        for item in row:
            try:
                corrected_row.append(float(item))
            except ValueError:
                corrected_row.append(correct_content(item))

        try:
            ws1.append(corrected_row)
        except Exception as e:
            wb = openpyxl.Workbook()
            virtual_file = BytesIO()
            ws1 = wb.active
            ws1.title = methodname

            # Corpus info
            ws1.append([f'corpus: {c(params.get("corpname", ""))}'])
            ws1.append([f'subcorpus: {c(params.get("usesubcorp", "-"))}'])
            if data.get('concsize', False):
                ws1.append([f'concordance size: {int(data["concsize"])}'])
            if (data.get('Desc', '')):
                ws1.append(['query: {}'.format(';'.join(
                    [c(d.get('op', 'operation')) + ':' + c(d.get('arg', 'argument')) \
                     for d in data['Desc']]))])

            ws1.append([f'Something went wrong ({e}). Please contact Sketchengine support.'])
            wb.save(virtual_file)
            outf.buffer.write(virtual_file.getvalue())
            return

    from openpyxl.styles import Alignment
    dims = {}
    for row in ws1.rows:
        for cell in row:
            if cell.value:
                cell.alignment = Alignment(wrap_text=True,vertical='top')
                # cell.style.alignment.wrap_text=True
                dims[cell.column_letter] = max((dims.get(cell.column_letter, 0), len(str(cell.value))))

    for col, value in dims.items():
        ws1.column_dimensions[col].width = value

    wb.save(virtual_file)
    outf.buffer.write(virtual_file.getvalue())


def xml(methodname, data, outf, nl, params):
    # =====================================================
    # FCS has special XML format
    if methodname == 'fcs':
        outf.write("<?xml version='1.0' encoding='utf-8'?>" + nl)
        if data.get('xml_stylesheet'):
            outf.write('<?xml-stylesheet href="{xml_stylesheet}" type="text/xsl"?>'.format(xml_stylesheet=data.get("xml_stylesheet")) + nl)

        def error_message():
            outf.write(' '*4 +'<sru:diagnostics xmlns:diag="http://www.loc.gov/zing/srw/diagnostic/">' + nl)
            outf.write(' '*8 + "<diag:diagnostic>" + nl)
            outf.write(' '*12 + "<diag:uri>info:srw/diagnostic/1/{code}</diag:uri>".format(code=data.get('code', 'UNKNOWN')) + nl )
            outf.write(' '*12 + "<diag:details>{details}</diag:details>".format(details=data.get('details', 'UNKNOWN')) + nl)
            outf.write(' '*12 + "<diag:message>{msg}</diag:message>".format(msg=data.get('msg', 'UNKNOWN')) + nl)
            outf.write(' '*8 + "</diag:diagnostic>" + nl)
            outf.write(' '*4 +"</sru:diagnostics>" + nl)

        # =============================================================

        if data['operation'] == 'explain':
            all_attr = ''
            for attr in data['result']:
                all_attr += ' '*20 + '<zr:index search="true" scan="true" sort="true">' + nl
                all_attr += ' '*24 + '<zr:title lang="en" primary="true">{attr}</zr:title>'.format(attr=attr) + nl
                all_attr += ' '*24 + '<zr:map primary="true">' + nl
                all_attr += ' '*28 + '<zr:name>{attr}</zr:name>'.format(attr=attr) + nl
                all_attr += ' '*24 + '</zr:map>' + nl
                all_attr += ' '*20 + '</zr:index>' + nl

            outf.write('<sru:explainResponse xmlns:sru="http://www.loc.gov/zing/srw/">' + nl)
            outf.write(' '*4 + "<sru:version>{api_version}</sru:version>".format(api_version=data.get('version', 'UNKNOWN')) + nl)
            outf.write(' '*4 + "<sru:record>" + nl)
            outf.write(' '*8 + "<sru:recordSchema>http://explain.z3950.org/dtd/2.0/</sru:recordSchema>" + nl)
            outf.write(' '*8 + "<sru:recordPacking>{recordPacking}</sru:recordPacking>".format(recordPacking=data.get('recordPacking', 'UNKNOWN')) + nl)
            outf.write(' '*8 + "<sru:recordData>" + nl)
            outf.write(' '*12 + '<zr:explain xmlns:zr="http://explain.z3950.org/dtd/2.0/">' + nl)
            outf.write(' '*16 + '<zr:serverInfo protocol="SRU" version="{api_version}" transport="http" method="GET POST SOAP">'.format(api_version=data.get('version', 'UNKNOWN')) + nl)
            outf.write(' '*20 + '<zr:host>{server_name}</zr:host>'.format(server_name=data.get('server_name', 'UNKNOWN')) + nl)
            outf.write(' '*20 + '<zr:port>{server_port}</zr:port>'.format(server_port=data.get('server_port', 'UNKNOWN')) + nl)
            outf.write(' '*20 + '<zr:database>{database}</zr:database>'.format(database=data.get('database', 'UNKNOWN')) + nl)
            outf.write(' '*16 + '</zr:serverInfo>' + nl)
            outf.write(' '*16 + '<zr:databaseInfo>' + nl)
            outf.write(' '*20 + '<zr:title lang="en" primary="true">{corpname}</zr:title>'.format(corpname=data.get('pretty_corpname', 'UNKNOWN')) + nl)
            outf.write(' '*16 + '</zr:databaseInfo>' + nl)
            outf.write(' '*16 + '<zr:indexInfo>' + nl)
            outf.write(' '*20 + '<zr:set identifier="clarin.eu/fcs/1.0" name="fcs">' + nl)
            outf.write(' '*24 + '<zr:title lang="de">CLARIN Content Search</zr:title>' + nl)
            outf.write(' '*24 + '<zr:title lang="en" primary="true">CLARIN Content Search</zr:title>' + nl)
            outf.write(' '*20 + '</zr:set>' + nl)
            outf.write('{all_attr}'.format(all_attr=all_attr))
            outf.write(' '*16 + '</zr:indexInfo>' + nl)
            outf.write(' '*16 + '<zr:schemaInfo>' + nl)
            outf.write(' '*20 + '<zr:schema identifier="http://clarin.eu/fcs/1.0" name="fcs">' + nl)
            outf.write(' '*24 + '<zr:title lang="en" primary="true">CLARIN Content Search</zr:title>' + nl)
            outf.write(' '*20 + '</zr:schema>' + nl)
            outf.write(' '*16 + '</zr:schemaInfo>' + nl)
            outf.write(' '*16 + '<zr:configInfo>' + nl)
            outf.write(' '*20 + '<zr:setting type="maximumRecords">{maximumRecords}</zr:setting>'.format(maximumRecords=data.get("maximumRecords", 'UNKNOWN')) + nl )
            outf.write(' '*16 + '</zr:configInfo>' + nl)
            outf.write(' '*12 + '</zr:explain>' + nl)
            outf.write(' '*8 + '</sru:recordData>' + nl)
            outf.write(' '*4 + '</sru:record>' + nl)
            if data.get('error', 0):
                error_message()
            outf.write('</sru:explainResponse>' + nl)

        # =============================================================
        # search = make concordance
        elif data['operation'] == 'searchRetrieve':
            all_results = ''
            for kwickline in data['result']:
                all_results += ' '*24 + '<kwic:kwic xmlns:kwic="http://clarin.eu/fcs/1.0/kwic">' + nl
                all_results += ' '*28 + '<kwic:c type="left">{lc}</kwic:c>'.format(lc=kwickline[0]) + nl
                all_results += ' '*28 + '<kwic:kw>{kwic}</kwic:kw>'.format(kwic=kwickline[1]) + nl
                all_results += ' '*28 + '<kwic:c type="right">{rc}</kwic:c>'.format(rc=kwickline[2]) + nl
                all_results += ' '*24 + '</kwic:kwic>' + nl


            outf.write('<sru:searchRetrieveResponse xmlns:sru="http://www.loc.gov/zing/srw/">' + nl)
            outf.write(' '*4 + '<sru:version>{version}</sru:version>'.format(version=data.get('version')) + nl)
            outf.write(' '*4 + '<sru:numberOfRecords>{numberOfRecords}</sru:numberOfRecords>'.format(numberOfRecords=data.get('numberOfRecords')) + nl)
            if int(data.get('numberOfRecords', 0)) > 0:
                outf.write(' '*4 + '<sru:records>' + nl)
                outf.write(' '*8 + '<sru:record>' + nl)
                outf.write(' '*12 + '<sru:recordSchema>http://clarin.eu/fcs/1.0</sru:recordSchema>' + nl)
                outf.write(' '*12 + '<sru:recordPacking>{recordPacking}</sru:recordPacking>'.format(recordPacking=data.get('recordPacking', 'UNKNOWN')) + nl)
                outf.write(' '*12 + '<sru:recordData>' + nl)
                outf.write(' '*16 + '<fcs:Resource xmlns:fcs="http://clarin.eu/fcs/1.0" pid="{corpname}" ref="{corpname}">'.format(corpname=data.get('corpname', 'UNKNOWN')) + nl)
                outf.write(' '*20 + '<fcs:DataView type="application/x-clarin-fcs-kwic+xml">' + nl)
                outf.write('{results}'.format(results=all_results))
                outf.write(' '*20 + '</fcs:DataView>' + nl)
                outf.write(' '*16 + '</fcs:Resource>' + nl)
                outf.write(' '*12 + '</sru:recordData>' + nl)
                outf.write(' '*8 + '</sru:record>' + nl)
                outf.write(' '*4 + '</sru:records>' + nl)

            if data.get('error', 0):
                error_message()
            outf.write('</sru:searchRetrieveResponse>' + nl)



        # =============================================================
        # scan = wordlist
        elif data['operation'] == 'scan':
            all_items = ''
            for item in data['result']:
                all_items += ' '*8 + "<sru:term>" + nl
                all_items += ' '*12 + "<sru:value>{item}</sru:value>".format(item=item[0]) + nl
                all_items += ' '*12 + "<sru:numberOfRecords>{freq}</sru:numberOfRecords>".format(freq=item[1]) + nl
                all_items += ' '*12 + "<sru:displayTerm>{item}</sru:displayTerm>".format(item=item[0]) + nl
                all_items += ' '*8 + "</sru:term>" + nl

            outf.write('<sru:scanResponse xmlns:sru="http://www.loc.gov/zing/srw/">' + nl)
            outf.write(' '*4 + "<sru:version>{api_version}</sru:version>".format(api_version=data.get('version', 'UNKNOWN')) + nl)
            if data.get('error', 0):
                error_message()
            else:
                if all_items:
                    outf.write(' '*4 + "<sru:terms>" + nl)
                    outf.write("{all_items}".format(all_items=all_items))
                    outf.write(' '*4 + "</sru:terms>" + nl)

            outf.write("</sru:scanResponse>" + nl)

        # =============================================================
        # scan fcs.resource = list of corpora

        elif data['operation'] == 'fcs.resource':
            all_result = ''
            for c in data['FCSCorpora']:
                all_result += ' '*8 + "<sru:term>" + nl
                all_result += ' '*12 + "<sru:value>{c_id}</sru:value>".format(c_id=c.get('id', 'UNKNOWN')) + nl
                all_result += ' '*12 + "<sru:displayTerm>{c_name}</sru:displayTerm>".format(c_name=c.get('name', 'UNKNOWN')) + nl
                if data['resource_info']:
                    all_result += ' '*12 + "<sru:extraTermData>" + nl
                    all_result += ' '*16 + '<ResourceInfo xmlns="http://clarin.eu/fcs/1.0/resource-info" hasSubResources="false">' + nl
                    all_result += ' '*20 + '<Description xml:lang="en">{c_description}</Description>'.format(c_description=c.get('description', 'UNKNOWN')) + nl
                    all_result += ' '*20 + '<LandingPageURI>{c_infohref}</LandingPageURI>'.format(c_infohref=c.get('infohref', 'UNKNOWN')) + nl
                    all_result += ' '*20 + '<Languages>' + nl
                    all_result += ' '*24 + '<Language>{c_language}</Language>'.format(c_language=c.get('language', 'UNKNOWN')) + nl
                    all_result += ' '*20 + '</Languages>' + nl
                    all_result += ' '*16 + '</ResourceInfo>' + nl
                    all_result += ' '*12 + '</sru:extraTermData>' + nl
                all_result += ' '*8 + '</sru:term>' + nl

            outf.write('<sru:scanResponse xmlns:sru="http://www.loc.gov/zing/srw/">' + nl)
            outf.write(' '*4 + '<sru:version>{version}</sru:version>'.format(version=data['version']) + nl)
            if data.get('error', 0):
                error_message()
            else:
                outf.write(' '*4 + '<sru:terms>' + nl)
                outf.write('{all_result}'.format(all_result=all_result))
                outf.write(' '*4 + '</sru:terms>' + nl)
            outf.write('</sru:scanResponse>' + nl)

    # ============================================================
    # Rest of methods
    else:
        export_note = params.get('export_note', '')
        outf.write("<?xml version='1.0' encoding='UTF-8' ?>" + nl)
        outf.write("<export>" + nl)
        outf.write("<header>" + nl)
        if export_note:
            outf.write("   <note>%s</note>" % n(export_note) + nl)
        outf.write("  <corpus>" + n(params.get('corpname', '-')) + '</corpus>' + nl)
        outf.write("  <subcorpus>" + n(params.get('usesubcorp', '-')) +\
                '</subcorpus>' + nl)
        if data.get('Desc'):
            outf.write("  <query>" + nl)
            for d in data['Desc']:
                outf.write('    <subquery operation="%s" size="%d">%s</subquery>' %\
                        (n(d.get('op', 'operation')), d.get('size', 0),\
                        n(d.get('arg', 'argument'))) + nl)
            outf.write('  </query>' + nl)
        outf.write('</header>' + nl)
        if 'error' in data:
            outf.write('  <error>An error occurred, check results in UI or in JSON format.</error>' + nl)
            outf.write('  <error>Error: %s</error>' % data['error'] + nl)
            outf.write("</export>" + nl)
            return
        if methodname in ['biterms']:
            showfrq = int(params.get('showfrq', '0'))
            showkeyness = int(params.get('showkeyness', '0'))
            showlogdice = int(params.get('showlogdice', '0'))
            outf.write('<biterms>' + nl)
            for item in data['Biterms']:
                for row in data['BitermsDict'][item]:
                    keyness = " keyness=\"%.3f\"" % float(row[5]) if showkeyness else ""
                    score = " score=\"%.3f\"" % float(row[7]) if showlogdice else ""
                    co_hits = " co-hits=\"%d\"" % int(row[2]) if showfrq else ""
                    source_hits = " hits=\"%d\"" % int(row[3]) if showfrq else ""
                    target_hits = " hits=\"%d\"" % int(row[4]) if showfrq else ""
                    source_term = n(row[0])
                    target_term = n(row[1])
                    outf.write(f"  <item{keyness}{score}{co_hits}>" + nl)
                    outf.write(f"    <source{source_hits}>{source_term}</source>" + nl)
                    outf.write(f"    <target{target_hits}>{target_term}</target>" + nl)
                    outf.write(f"  </item>" + nl)
            outf.write('</biterms>' + nl)

        elif methodname == 'wsketch':
            if not int(params.get('structured', True)):
                outf.write('<wordsketch>' + nl)
                outf.write(' '*2 + '<keyword pos="{}" freq="{}">{}</keyword>{}'.format(n(data.get('lpos', '')),
                                                                                    data.get('freq', 0),
                                                                                    n(data.get('lemma', '')),
                                                                                    nl))
                for item in data['Items']:
                    nicename = n(item['gramrel'].replace('"%w"', 'X').replace('%w', 'X'))
                    outf.write(' '*4 + '<coll hits="{}" score="{:.3f}" query="{}" gramrel="{}">'.format(item.get('count', 0),
                                                                                                        float(item['score'] or '0.0') or 0.0,
                                                                                                        item.get('conclink', ''),
                                                                                                        nicename))
                    outf.write(n(item.get('word', '')))
                    outf.write('</coll>' + nl)
                outf.write('</wordsketch>' + nl)
            else:
                outf.write('<wordsketch>' + nl)
                outf.write('  <keyword pos="%s" freq="%d">%s</keyword>' %\
                        (n(data.get('lpos', '')), data.get('freq', 0),
                        n(data.get('lemma', ''))) + nl)
                for gr in data['Gramrels']:
                    nicename = n(gr['name'].replace('"%w"', 'X').replace('%w', 'X'))
                    outf.write('  <gramrel name="%s" hits="%d" score="%.3f">' %\
                            (nicename, gr['count'] or 0,
                            float(gr['score'] or '0.0') or 0.0) + nl)
                    for w in gr['Words']:
                        outf.write('    <coll hits="%d" score="%.3f" query="%s">' %\
                                (w['count'], w['score'], w['conclink']))
                        outf.write(n(w.get('word', w.get('name', ''))))
                        outf.write('</coll>' + nl)
                    outf.write('  </gramrel>' + nl)
                outf.write('</wordsketch>' + nl)

        elif methodname == 'extract_keywords':
            items = data.get('keywords')
            all_attrs = ['item', 'frq1', 'frq2', 'rel_frq1', 'rel_frq2', 'docf1', 'docf2', 'rel_docf1', 'rel_docf2', 'arf1', 'arf2', 'aldf1', 'aldf2', 'star1', 'star2', 'score']
            outf.write('<collocations>' + nl)
            if items:
                attr_list = list(filter(lambda attr: attr in items[0], all_attrs))
                for item in items:
                    outf.write('  <collocation>')
                    for attr in attr_list:
                        node_name = attr.replace(':', '_')
                        outf.write('    <%s>%s</%s>' % (node_name, get_attr_formatted_value(attr, item[attr], nt), node_name) + nl)
                    outf.write('  </collocation>')
            outf.write('</collocations>' + nl)

        elif methodname.startswith('coll'):
            mldict = {x['s']:x['n'] for x in data['Head'] if 's' in x}
            outf.write('<collocations>' + nl)
            for item in data['Items']:
                outf.write('  <item>' + nl)
                outf.write('    <str>%s</str>' % n(item['str']) + nl)
                outf.write('    <freq>%d</freq>' % item['freq'] + nl)
                outf.write('    <collfreq>%d</collfreq>' % item['coll_freq'] + nl)
                for sc in item['Stats']:
                    outf.write('    <score type="%s">%.5f</score>' %\
                            (mldict.get(sc['n'], ''), float(sc['s'])) + nl)
                outf.write('  </item>' + nl)
            outf.write('</collocations>' + nl)

        elif methodname == 'concordance':
            outf.write('<concordance>' + nl)

            def printl(ln, l):
                outf.write('  <line refs="{0}" num="{1}" label="{2}"'.format(n(','.join(l.get('Refs', []))),
                                                                                 ln,
                                                                                 n(l.get('linegroup', '_'))))
                if data.get('gdex_scores', False):
                    gdex_sore = "{:.5f}".format(data['gdex_scores'][l['toknum']])
                    outf.write(' gdex_score="{}"'.format(gdex_sore))
                outf.write('>' + nl)

                left = ' '.join([n(scoll(x)) for x in l['Left']])
                kwic = ' '.join([n(s(x)) for x in l['Kwic']])
                right = ' '.join([n(scoll(x)) for x in l['Right']])
                outf.write('    <left>%s</left>' % left + nl)
                outf.write('    <kwic>%s</kwic>' % kwic + nl)
                outf.write('    <right>%s</right>' % right + nl)
                outf.write('  </line>' + nl)

            for i, line in enumerate(data['Lines']):
                if line.get('Align', []):
                    outf.write('  <parallel_lines>' + nl)
                    printl(i, line)
                    for j, al in enumerate(line['Align']):
                        printl(j, al)
                    outf.write('  </parallel_lines>' + nl)
                else:
                    printl(i, line)
            outf.write('</concordance>' + nl)

        elif methodname.startswith('freq') or methodname == 'struct_wordlist':
            all_attrs = get_frq_attrs(data)
            outf.write('<frequency>' + nl)
            for block in data['Blocks']:
                attrd = {x['s']:n(x['n']) for x in block['Head'] if 'id' in x}
                outf.write('  <items blockname="%s">' %\
                        n(block.get('blockname', '')) + nl)
                for item in block['Items']:
                    outf.write('    <item>' + nl)
                    for i, w in enumerate(item['Word']):
                        outf.write('      <str attribute="%s">%s</str>' %\
                                (attrd.get(i, 'str'), n(w['n']).replace('  ', ' '))
                                + nl)
                    attr_list = list(filter(lambda attr: attr in item, all_attrs))
                    for attr in attr_list:
                        node_name = attr.replace(':', '_')
                        outf.write('    <%s>%s</%s>' % (node_name, get_attr_formatted_value(attr, item[attr], double_spaces), node_name) + nl)
                    outf.write('    </item>' + nl)
                outf.write('  </items>' + nl)
            outf.write('</frequency>' + nl)

        elif methodname == 'thes':
            outf.write('<thesaurus>' + nl)
            outf.write('  <keyword pos="%s" freq="%d">%s</keyword>' %\
                    (data.get('lpos', ''), data['freq'],
                    n(data.get('lemma', ''))) + nl)
            for w in data['Words']:
                if 'Clust' in w:
                    outf.write('  <cluster head="%s">' % n(w['word']) + nl)
                outf.write('  <item score="%.3f" freq="%d">%s</item>' %\
                        (w['score'], w['freq'], n(w['word'])) + nl)
                if 'Clust' in w:
                    for cl in w['Clust']:
                        outf.write('  <item score="%.3f" freq="%d">%s</item>' %\
                                (cl['score'], cl['freq'], n(cl['word'])) + nl)
                    outf.write('  </cluster>' + nl)
            outf.write('</thesaurus>' + nl)

        elif methodname in ['wordlist', 'poswordlist']:
            items = data.get('Items', [])
            all_attrs = ['str', 'frq', 'relfreq', 'docf', 'reldocf', 'arf', 'aldf', 'star:f', 'rnk:f', 'norm:l', 'token:l']
            usengrams = params.get('usengrams', "0")
            nest_ngrams = params.get('nest_ngrams', "0")

            def print_line(item, level=0):
                if params.get('wlattr') == 'WSCOLLOC': # wordlist from collocations
                    hwd, rel, col = item['str'].split('\t')[:3]
                    outf.write('  <item>' + nl)
                    outf.write('    <hwd>%s</hwd>' % get_attr_formatted_value('str', hwd, double_spaces_tab) + nl)
                    outf.write('    <rel>%s</rel>' % get_attr_formatted_value('str', rel, double_spaces_tab) + nl)
                    outf.write('    <col>%s</col>' % get_attr_formatted_value('str', col, double_spaces_tab) + nl)
                else:
                    outf.write('  <item>' + nl)
                    outf.write('    <str>%s</str>' % ('—' * level + get_attr_formatted_value('str', item['str'], double_spaces_tab)) + nl)
                for attr in attr_list:
                    node_name = attr.replace(':', '_')
                    outf.write('    <%s>%s</%s>' % (node_name, get_attr_formatted_value(attr, item[attr], double_spaces), node_name) + nl)
                outf.write('  </item>' + nl)

            def nested(ngram, level=0):
                if level:
                    print_line(ngram, level)
                for ch in ngram.get('children', []):
                    nested(ch, level+1)

            if items:
                attrs = [params.get('wlsort')]  \
                    + params.get('wlnums', '').split(',')  \
                    + (['relfreq'] if params.get('relfreq', False) else [])  \
                    + (['reldocf'] if params.get('reldocf', False) else [])

                attr_list = list(filter(lambda attr: attr in attrs and attr in items[0], all_attrs))

                outf.write('<wordlist attr="%s">' % params.get('wlattr', '') + nl)
                for i in items:
                    print_line(i)
                    if usengrams == 1 and nest_ngrams == 1 and i.get('children', []):
                        nested(i)
                outf.write('</wordlist>' + nl)

        elif methodname == 'wsdiff':
            outf.write('<wsdiff word1="%s" word2="%s">' % (n(data['lbl1']),
                    n(data['lbl2'])) + nl)
            for gr in data['content']['common']:
                h = gr['table']['Header']
                outf.write('  <relation name="%s" hits1="%d" hits2="%d" '
                        'score1="%.3f" score2="%.3f">' % (n(h[0]), int(h[1]),
                        int(h[2]), float(h[3]), float(h[4])) + nl)
                for r in gr['table']['Rows']:
                    outf.write('    <item hits1="%d" hits2="%d" score1="%s" '
                            'score2="%s" class="%s">%s</item>' % (int(r['cnt1']),
                            int(r['cnt2']), r['rnk1'] or '--', r['rnk2'] or '--',
                            r['class'], n(r['word'])) + nl)
                outf.write('  </relation>' + nl)
            outf.write('</wsdiff>' + nl)

        elif methodname == 'trends':
            # dict results = [_id, w, trend, p, f, simple_trend]
            def print_line(item, level=0):
                _id, w, trend, p, f, simple_trend = item
                outf.write('  <item>' + nl)
                outf.write(f'    <str>{c(w)}</str>' + nl)
                outf.write(f'    <trend>{trend}</trend>' + nl)
                outf.write(f'    <p_value>{"{:.20f}".format(p).rstrip("0").rstrip(".")}</p_value>' + nl)
                outf.write(f'    <frq>{f}</frq>' + nl)
                outf.write(f'    <simple_trend>{trend_dict[int(simple_trend)]}</simple_trend>' + nl)
                outf.write(f'    <simple_trend_number>{simple_trend}</simple_trend_number>' + nl)
                outf.write('  </item>' + nl)

            outf.write('<trends attr="%s">' % params.get('trends_attr', '') + nl)
            for item in data['result']:
                print_line(item)
            outf.write('</wordlist>' + nl)

        else:
            outf.write('<error>Method %s does not support XML export!</error>' %\
                    methodname + nl)
        outf.write("</export>" + nl)

def tbx(methodname, data, outf, nl, params):
    export_note = params.get('export_note', '')
    outf.write("<?xml version='1.0' encoding='UTF-8' ?>" + nl)
    def print_prefix():
        outf.write('<martif type="TBX" xml:lang="">' + nl)
        outf.write('  <martifHeader>' + nl)
        outf.write('    <fileDesc>' + nl)
        outf.write('      <titleStmt>' + nl)
        outf.write('        <title>Sketch Engine Terminology Extraction</title>' + nl)
        outf.write('      </titleStmt>' + nl)
        outf.write('      <sourceDesc>' + nl)
        if export_note:
            outf.write('        <p>%s</p>' % n(export_note) + nl)
        outf.write('        <p>Source corpus: %s' % data.get('corpus', '') + nl)
        outf.write('          reference corpus: %s' % data.get('ref_corpus', '') + nl)
        outf.write('      </sourceDesc>' + nl)
        outf.write('    </fileDesc>' + nl)
        outf.write('  </martifHeader>' + nl)
        outf.write('  <text>' + nl)
        outf.write('    <body>' + nl)
    def print_suffix():
        outf.write('    </body>' + nl)
        outf.write('  </text>' + nl)
        outf.write('</martif>' + nl)
    if 'error' in data:
        outf.write('      <error>An error occurred, check results in UI or in JSON format.</error>' + nl)
        outf.write('      <error>Error: %s</error>' % data['error'] + nl)
        print_suffix()
        return
    if methodname == 'extract_keywords':
        items = data.get('keywords', [])
        all_attrs = ['frq1', 'frq2', 'rel_frq1', 'rel_frq2', 'docf1', 'docf2', 'rel_docf1', 'rel_docf2', 'arf1', 'arf2', 'aldf1', 'aldf2', 'star1', 'star2', 'score']
        print_prefix()
        if items:
            attr_list = list(filter(lambda attr: attr in items[0], all_attrs))
            for i, item in enumerate(items, 1):
                outf.write('      <termEntry id="%d">' % i + nl)
                outf.write('        <langSet xml:lang="">' + nl)
                outf.write('          <ntig>' + nl)
                outf.write('            <termGrp>' + nl)
                for item in items:
                    outf.write('              <term id="t%d">%s</term>' % (i, n(item['item'])) + nl)
                    for attr in attr_list:
                        outf.write('              <termNote type="%s">%s</termNote>' % (attr, get_attr_formatted_value(attr, item[attr])) + nl)
                outf.write('            </termGrp>' + nl)
                outf.write('          </ntig>' + nl)
                outf.write('        </langSet>' + nl)
                outf.write('      </termEntry>' + nl)
        print_suffix()

    elif methodname == 'biterms':
        print_prefix()
        for i, item in enumerate(data['Biterms'], 1):
            b = data['BitermsDict'][item][0]
            outf.write('      <termEntry id="%d">' % i + nl)
            outf.write('        <langSet xml:lang="l1">' + nl)
            outf.write('          <ntig>' + nl)
            outf.write('            <termGrp>' + nl)
            outf.write('              <term id="t1_%d">%s</term>' %\
                    (i, n(b[0])) + nl)
            outf.write('              <termNote type="score">%.3f</termNote>' %\
                    float(b[7]) + nl)
            outf.write('              <termNote type="frequency">%d</termNote>' %\
                    int(b[2]) + nl)
            outf.write('            </termGrp>' + nl)
            outf.write('          </ntig>' + nl)
            outf.write('        </langSet>' + nl)
            outf.write('        <langSet xml:lang="l2">' + nl)
            outf.write('          <ntig>' + nl)
            outf.write('            <termGrp>' + nl)
            outf.write('              <term id="t2_%d">%s</term>' %\
                    (i, n(b[0])) + nl)
            outf.write('              <termNote type="score">%.3f</termNote>' %\
                    float(b[7]) + nl)
            outf.write('              <termNote type="frequency">%d</termNote>' %\
                    int(b[3]) + nl)
            outf.write('            </termGrp>' + nl)
            outf.write('          </ntig>' + nl)
            outf.write('        </langSet>' + nl)
            outf.write('      </termEntry>' + nl)
        print_suffix()
    else:
        outf.write('<error>Method %s does not support TBX export!</error>' %\
                methodname + nl)

def json(methodname, data, outf, nl, params):
    data['request'] = params
    # this try-except block is an important debuging construction and will be gotten rid of
    try:
        jsonlib.dump(data, outf)
    except:
        raise Exception(str(data))

map = {
    'csv': csv,
    'xml': xml,
    'json': json,
    'tbx': tbx,
    'xlsx': xlsx,
    'txt': txt,
    'tmx': tmx
}

def export(publisher, methodname, data, format='json', outf=sys.stdout, nl='\n', params={}):
    global cgi_publisher
    cgi_publisher = publisher
    if format in map:
        map[format](methodname, data, outf, nl, params)
    else:
        outf.write('Export to format "%s" not supported\n' % format)
    outf.flush()
