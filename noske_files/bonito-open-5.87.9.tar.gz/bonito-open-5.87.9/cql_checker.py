#!/usr/bin/python3
# coding: utf-8
# Author: Marek Medved, marek.medved@sketchengine.eu, Lexical Computing CZ
import re
import manatee


token_re = re.compile(r'\[([\s(]*([a-z_@]+\s*[=<>!]+\s*".*?"|ws\(.*?\)|term\(.*?\)|swap\(.*?\)|ccoll\(.*?\))+\s*(&|\||and|or)?[\s)]*)*\s*\]')
struct_re = re.compile(r'<\s*[^>\s]+\s*([#!-0-9]+)*\s*(\(?\s*[^>\s]+="[^>"]+"\)?)*\s*/?>')
                     

def is_full_cql(cql):
    sub = ''
    query_sub = re.sub(r'\\"', sub, cql)
    query_sub = re.sub(r'\\\[', sub, query_sub)
    query_sub = re.sub(r'\\\]', sub, query_sub)
    query_sub = token_re.sub(sub, query_sub)
    query_sub = struct_re.sub(sub, query_sub)
    query_sub = re.sub(r'(within|containing|meet|union)', sub, query_sub)  # special operators
    query_sub = re.sub(r'{\d*(,\d+)?}', sub, query_sub)  # ranges
    query_sub = re.sub(r'\d+[.:]', sub, query_sub)  # position marks
    query_sub = re.sub(r'[:?!()]+', sub, query_sub)
    query_sub = re.sub(r'-?\d+', sub, query_sub)
    query_sub = re.sub(r'~".*?"', sub, query_sub)

    if re.search(r'".*?"', query_sub):
        return False
    
    return True


def check_cql(corpname, cql):
    corp = manatee.EmptyCorpus(corpname)
    corp.eval_query(cql)


if __name__ == '__main__':
    import unittest
    class TestStringMethods(unittest.TestCase):
        def test_accepted(self):
            self.assertTrue(is_full_cql('[word@word_diac="والتي" | lemma@lemma_diac="والتي"]'))
            self.assertTrue(is_full_cql('([lemma="be" | lemma="get"] [tag = "R*" | tag = "XX"]{0,100} [tag="VVN"] []{0,10} [tag="CC"][tag = "R*" | tag = "XX"]{0,100} [tag="VVN"] ) within <s/>'))
            self.assertTrue(is_full_cql('[lc="(j?)(e?)sem(ť?)|(j?)si(ť?)|(j?)s|j|je(ť?)|jest(ť?)|jest[oi](ť?)|(j?)sm[aey](ť?)|(j?)(e?)st[ae](ť?)|(j?)(e?)sú(ť?)|(j?)sou(ť?)|(j?)(e?)sv[aě](ť?)"]'))
            self.assertTrue(is_full_cql('([lemma = "be|get"] [tag = "AT.*"]? [tag = "N.*" | tag = "APPGE|P.*"] [tag = "R.*|XX"]{0,100} [tag = "VVN"] []{0,100} [word = "\?"]) within <s/>'))
            self.assertTrue(is_full_cql('(([lemma="assalto"][]{0,05}[lemma="Covid|Covid-19|coronavirus"]) | ([lemma="Covid|Covid-19|coronavirus"][]{0,05} [lemma="assalto"]))within <s/>'))
            self.assertTrue(is_full_cql('[(ccoll(1, 2, swap(1, ws(2, 281522868944))) & ws(1, 6003424275))|(ccoll(1, 2, swap(1, ws(2, 281522868944))) & ws(1, 6003424269))]'))
            self.assertTrue(is_full_cql('[tag="N.*"] [tag="SP"]{1,2} [tag="RN"]{0,1} [tag="VMN.*" & word=".*[^-lo]|.*[^-ne]"] (< s/> | [tag!="N.*|V.*|C.*|SP|D.*|A.*"])'))
            self.assertTrue(is_full_cql('[ws("test-n", "\.\.\. (of|in|at) \"%w\"", ".*") | ws("test-n", "\"%w\" (of|in|at) \.\.\.", ".*")]'))
            self.assertTrue(is_full_cql('(1:[tag="N.*"] [ ]{0,3} 2:[tag="V.*"] within < s/>) & 1.lemma=2.lemma & 1.lc!=2.lc'))
            self.assertTrue(is_full_cql('(union (meet [tag="N.*"] [tag="VB.*"] -3 3) (meet [tag="A.*"] [tag="VB.*"] -2 2))'))
            self.assertTrue(is_full_cql('(meet [ws("test-n",".*modifiers of.*","blood-n")] [lemma="be"] -1 1)'))
            self.assertTrue(is_full_cql('[tag="J.*"]{1,2}[tag="N.*"]{1,5}[tag="V.*"][tag="R.*"]{1,2} within 5'))
            self.assertTrue(is_full_cql('[lempos_lc="charlar-v"][lempos_lc="estar-v"][lempos_lc="caminar-v"]'))
            self.assertTrue(is_full_cql('1:[] 2:[] []{3,10} 3:[] & 1.tag = 2.tag & 3.lemma=1.lemma'))
            self.assertTrue(is_full_cql('<s/> containing [word="feedback"] [word="information"]'))
            self.assertTrue(is_full_cql('[tag="N.*"] within [tag="VB.*"] []{0,5} [tag="VB.*"]'))
            self.assertTrue(is_full_cql('~10"at-i" [ws("family-n", "subject_of", "be-v")]'))
            self.assertTrue(is_full_cql('[word="car"] within europarl5_de: [word="Auto"]'))
            self.assertTrue(is_full_cql('[ word="round" & ( tag="N.*" | tag="V.*" ) ]'))
            self.assertTrue(is_full_cql('[tag="V.*"]  within <doc style="informal" />'))
            self.assertTrue(is_full_cql('[word="\\/|\[|\|"] [word!="\/|\[|\|"]{,20}'))
            self.assertTrue(is_full_cql('[word="test"] within <doc (topic="t1") />'))
            self.assertTrue(is_full_cql('[lemma="^a([a-zõüöä]){4}ne$" & tag="A"]'))
            self.assertTrue(is_full_cql('<doc style="informal">[lemma="Rebecca"]'))
            self.assertTrue(is_full_cql('[ws("book-n", ".*", ".*") & tag="NNS"]'))
            self.assertTrue(is_full_cql('[lemma=="היות" & tag=="conjunction"]'))
            self.assertTrue(is_full_cql('his being [tag="APPGE" & tag="V.G"]'))
            self.assertTrue(is_full_cql('[lemma="chop"] []{0,3} ~"carrot-n"'))
            self.assertTrue(is_full_cql('[tag="N.*"]   !within   < nphr/>'))
            self.assertTrue(is_full_cql('[] [lemma="work"] []'))
            self.assertTrue(is_full_cql('![tag="N.*"]'))
            self.assertTrue(is_full_cql('[word<="."]'))

        def test_declined(self):
            self.assertFalse(is_full_cql('([lemma = "be|get"] [tag = "AT.*"]? ["N.*|APPGE|P.*"] [tag = "R.*|XX"]{0,100} [tag = "VVN"] []{0,100} [word = "\?"]) within <s/>'))
            self.assertFalse(is_full_cql('"a" "common|cultural|social|universal|widespread|worldwide" "phenomenon"'))
            self.assertFalse(is_full_cql('"regard|view|see|consider|interpret" [tag="NN.*"] "as"'))
            self.assertFalse(is_full_cql('"all""the"[tag="NNS"]'))
            self.assertFalse(is_full_cql('"als|denn|wie" "ever"'))
            self.assertFalse(is_full_cql('"minurr.*|minarr.*"'))
            self.assertFalse(is_full_cql('"carrot-n"'))

    unittest.main()
