#!/usr/bin/python3
# coding: utf-8
# Author: Marek Medved, marek.medved@sketchengine.eu, Lexical Computing CZ
import os
import re
import smtplib
from email.message import EmailMessage
from CGIPublisher import CGIPublisher


class RegisterUser(CGIPublisher):
    address = ''
    phone = ''

    def _send_mail(self, subject, message, to_mail):
        """
        Send mail via SMTP
        :param subject: str
        :param message: str
        :param to_mail: str
        :return: None
        """
        msg = EmailMessage()
        msg['Subject'] = f'{subject}'
        msg['From'] = self._from_mail
        msg['To'] = [to_mail]

        msg.set_content(f"""\
        <html>
            <head></head>
            <body>
            {message}
            </body>
        </html>
        """, subtype='html')

        s = smtplib.SMTP(self._smtp_server)
        s.send_message(msg)
        s.quit()

    @staticmethod
    def _get_user_list(file, item=0, separator='\t', admins=[]):
        """
        Read user data from files
        :param file: str
        :param item: int, position in tsv
        :param admins: list, list of admin users
        :return: list, int -> list of required data, status of read command
        """
        u_list = []
        status = 1
        try:
            with open(file, 'r', encoding='utf-8') as f:
                for line in f:
                    if admins:
                        user_name = line.strip('\n').split(separator)[0]
                        if user_name in admins:
                            u_list.append(line.strip('\n').split(separator)[item])
                    else:
                        u_list.append(line.strip('\n').split(separator)[item])
        except:
            status = 0

        return u_list, status

    @staticmethod
    def _get_user_password(file, req_user, req_mail):
        """
        Read user data from files
        :param req_user: str
        :param req_mail: str
        :return: list, int -> list of required data, status of read command
        """
        password_hash = ''
        status = 1
        try:
            with open(file, 'r', encoding='utf-8') as f:
                for line in f:
                    spl = line.strip('\n').split('\t')
                    user = spl[0]
                    mail = spl[2]
                    if user == req_user and mail == req_mail:
                        password_hash = spl[5]
                        break
        except:
            status = 0

        return password_hash, status

    @staticmethod
    def _write_user_data(file, data):
        """
        Write user data to files
        :param file: str
        :param data: str, user data
        :return: int -> status of write command
        """
        status = 1
        try:
            with open(file, 'a+', encoding='utf-8') as f:
                f.write(f'{data}\n')
        except:
            status = 0

        return status
    
    @staticmethod
    def _check_tabs(data):
        """
        :param data: list
        :return: bool
        """
        for item in data:
            if '\t' in item:
                return True
        return False

    def register_user_new(self):
        """
        Create e-mail for admin to approve or deny new user
        :return: json status
        """
        if not self._enable_registration:
            return {'status': 'fail', 'message': 'Registration is not enabled.'}

        import subprocess

        # Load user data
        known_users, s1 = self._get_user_list(f'{self._user_data_path}/users')
        known_mails, s2 = self._get_user_list(f'{self._user_data_path}/users', item=2)
        known_admins, s3 = self._get_user_list(f'{self._user_data_path}/admins')
        admin_mail_list, s4 = self._get_user_list(f'{self._user_data_path}/users', item=2, admins=known_admins)

        # error loading data
        if not (s1 and s2 and s3 and s4):
            return {'status': 'fail', 'message': 'Server Error. User data not available. Contact admin.'}

        # deny known users
        if self.username in known_users:
            return {'status': 'fail', 'message': 'User with this login already exists.'}
        # deny known user emails
        if self.mail in known_mails:
            return {'status': 'fail', 'message': 'User with this email already exists.'}

        # Generate password hash and store user data
        process = subprocess.Popen(['htpasswd', '-bn', self.username, self.password],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        htpasswd_stdout, _ = process.communicate()

        if process.returncode != 0:
            return {'status': 'fail',
                    'message': f'Problem while storing data. Contact admin: CODE:{process.returncode}.'}

        password_hash = re.match(f'^{self.username}:(.+)$', htpasswd_stdout.decode('utf-8').strip()).group(1)

        # No tabs in input allowed:
        if self._check_tabs([self.username, self.fullname, self.mail, self.address, self.phone]):
            return {'status': 'fail', 'message': 'No tabs are allowed inside user data.'}

        if not self._write_user_data(f'{self._user_data_path}/users',
                                     f'{self.username}\t{self.fullname}\t{self.mail}\t'
                                     f'{self.address}\t{self.phone}\t{password_hash}'):
            return {'status': 'fail', 'message': 'Problem while storing data. Contact admin.'}

        if self._enable_mail:
            # Send new registration mail to admins
            user_data = f'username={self.username}&' \
                        f'mail={self.mail}'

            approve_url = f'{self._registration_url}/register_user_approve?{user_data}'
            deny_url = f'{self._registration_url}/register_user_deny?{user_data}'

            message = self._registration_message.format(username=self.username,
                                                       fullname=self.fullname,
                                                       mail=self.mail,
                                                       phone=self.phone,
                                                       address=self.address,
                                                       approve_url=approve_url,
                                                       deny_url=deny_url)
            for admin_mail in admin_mail_list:
                self._send_mail(f'{self._registration_message_subject} {self.username}', message, admin_mail)

            return {'status': 'ok', 'message': 'Mail sent.'}
        else:
            # Allow access to new user
            registered_users, s3 = self._get_user_list(self._passwords_path, separator=':')
            if not s3:
                return {'status': 'fail', 'message': 'Problem while storing data. FileAccess Error admins files.'}

            if self.username in registered_users:
                return {'status': 'fail', 'message': 'User with this login already exists.'}
            else:
                self._write_user_data(self._passwords_path, f'{self.username}:{password_hash}')

            return {'status': 'ok', 'message': 'User has been created.', 'canLogin': 'true'}

    def register_user_approve(self):
        """
        Approve new user registration, store user data and send e-mail to new user
        :return: json status
        """
        if not self._enable_registration:
            return {'status': 'fail', 'message': 'Registration is not enabled.'}

        user = os.getenv('REMOTE_USER')
        # Require admin authentication
        if user:
            registered_users, s3 = self._get_user_list(self._passwords_path, separator=':')
            admin_users, s1 = self._get_user_list(f'{self._user_data_path}/admins')
            if not (s1 and s3):
                return {'status': 'fail', 'message': 'Problem while storing data. FileAccess Error admins files.'}

            # Check admin credentials
            if user not in admin_users:
                return {'status': 'fail',
                        'message': 'You must have admin credentials to be able to register a new user.'}

            # Store user data
            password_hash, s2 = self._get_user_password(f'{self._user_data_path}/users', self.username, self.mail)
            if not s2:
                return {'status': 'fail', 'message': 'Problem while loading data. FileAccess Error admins files.'}

            if self.username in registered_users:
                return {'status': 'fail', 'message': 'User with this login already exists.'}
            else:
                if not self._write_user_data(self._passwords_path, f'{self.username}:{password_hash}'):
                    return {'status': 'fail', 'message': 'Problem while writing data. FileAccess Error passwords files.'}
    
            # Send approve mail to user
            self._send_mail(self._approve_message_subject.format(username=self.username),
                            self._approve_message,
                            self.mail)

            return {'status': 'ok', 'message': 'User has been approved.'}
        else:
            return {'status': 'fail', 'message': 'Login as a admin'}

    def register_user_deny(self):
        """
        Deny user registration, store data and send e-mail
        :return: json status
        """
        if not self._enable_registration:
            return {'status': 'fail', 'message': 'Registration is not enabled.'}

        user = os.getenv('REMOTE_USER')
        # Require admin authentication
        if user:
            admin_users, s1 = self._get_user_list(f'{self._user_data_path}/admins')
            denied_users, s2 = self._get_user_list(f'{self._user_data_path}/invalid_users')
            if not (s1 and s2):
                return {'status': 'fail', 'message': 'Problem while storing data. FileAccess Error admins files.'}

            # Check admin credentials
            if user not in admin_users:
                return {'status': 'fail',
                        'message': 'You must have admin credentials to be able to deny a user'}

            # Store user data
            if self.username in denied_users:
                return {'status': 'fail', 'message': 'This user is already denied.'}
            else:
                if not self._write_user_data(f'{self._user_data_path}/invalid_users', self.username):
                    return {'status': 'fail', 'message': 'Problem while storing data. Contact admin.'}

            # Send deny mail to user
            self._send_mail(self._deny_message_subject.format(username=self.username),
                            self._deny_message,
                            self.mail)

            return {'status': 'ok', 'message': 'User was denied.'}
        else:
            return {'status': 'fail', 'message': 'Login as a admin'}
