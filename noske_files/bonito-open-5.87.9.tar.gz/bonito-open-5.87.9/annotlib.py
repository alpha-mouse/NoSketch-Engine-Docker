# Copyright (c) 2019-2020  Vit Baisa

import re
import os
from manatee import IntVector
import sqlite3
import json
import datetime
import itertools
from urllib.parse import unquote

DEFAULT_DB_NAME = "_skema.db"

class Annotation():
    def __init__(self, corp, ag, user=""):
        self.annotation_group = ag
        self.corp = corp
        self.user = user
        self._db_dir = corp._conc_dir
        dbfn = os.path.join(self._db_dir, DEFAULT_DB_NAME)
        if not os.path.exists(dbfn):
            self.conn = None
            self.cursor = None
        else:
            self.conn = sqlite3.connect(dbfn, timeout=10.0)
            self.conn.row_factory = sqlite3.Row
            self.cursor = self.conn.cursor()

    def __init_db(self):
        if not os.path.exists(self._db_dir):
            os.makedirs(self._db_dir)
        dbfn = os.path.join(self._db_dir, DEFAULT_DB_NAME)
        self.conn = sqlite3.connect(dbfn, timeout=10.0)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        self.cursor.execute("DROP TABLE IF EXISTS queries;")
        self.cursor.execute("DROP TABLE IF EXISTS labels;")
        self.conn.commit()
        self.cursor.execute("""
                CREATE TABLE queries(
                    id      INTEGER PRIMARY KEY,
                    query   CHAR(50) NOT NULL, -- e.g. verb
                    cql     TEXT,
                    conc    CHAR(200) NOT NULL UNIQUE, -- path (annotconc)
                    size    INTEGER, -- concordance size
                    status  CHAR(10), -- values defined in settings
                    sample  INTEGER, -- sample size
                    created DATETIME DEFAULT CURRENT_TIMESTAMP,
                    creator CHAR(30) NOT NULL,
                    edited  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    editor  CHAR(30) NOT NULL,
                    attr    TEXT -- JSON with additional attributes
                );""")
        self.conn.commit()
        self.cursor.execute("""
                CREATE TABLE labels(
                    id      INTEGER NOT NULL,
                    qid     INTEGER NOT NULL,
                    label   CHAR(30) NOT NULL,
                    data    TEXT, -- arbitrary structure in JSON
                    created DATETIME DEFAULT CURRENT_TIMESTAMP,
                    creator CHAR(30) NOT NULL,
                    edited  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    editor  CHAR(30) NOT NULL,
                    attr    TEXT, -- JSON with additional attributes
                    UNIQUE(qid, label),
                    PRIMARY KEY (id, qid),
                    FOREIGN KEY (qid) REFERENCES queries(id)
                );""")
        self.conn.commit()

    def store_query(self, queryname='', query='', concname='', size=0, sample=0):
        if self.conn is None:
            self.__init_db()
        if self.conc2id(concname) >= 0:
            return {'message': 'Already in DB'}
        dt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        q = """INSERT INTO queries
                (query, cql, conc, size, status, sample, creator, edited, editor, attr)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        self.cursor.execute(q, (queryname, query, concname, size, 'NEW',
                sample, self.user, dt, self.user, "{}"))
        qid = self.cursor.lastrowid
        self.conn.commit()
        self.add_label(qid, '_')
        self.add_label(qid, 'LABEL')
        return {'message': 'OK'}

    def get_query_by_id(self, qid):
        q = """SELECT * FROM queries
                WHERE id = ?;"""
        try:
            return self.cursor.execute(q, (qid, )).fetchone()
        except Exception as e:
            return None

    def del_conc(self, conc):
        return self.del_query(self.conc2id(conc))

    def del_query(self, qid):
        self.cursor.execute("DELETE FROM queries WHERE id = ?", (qid,))
        self.cursor.execute("DELETE FROM labels WHERE qid = ?", (qid,))
        self.conn.commit()
        return {'message': 'Query #%d deleted.' % qid}

    def rename_query(self, qid, concname):
        q = """UPDATE queries
                SET query = ?, conc = ?
                WHERE id = ?;"""
        self.cursor.execute(q, (concname, concname, qid))
        self.conn.commit()
        self.update_query_last_edited(qid)
        return {'message': 'Query #%d renamed.' % qid, 'qid': qid, 'concname': concname}

    def labmaxid(self, qid):
        q = "SELECT MAX(id) FROM labels WHERE qid = ?"
        r = self.cursor.execute(q, (qid,)).fetchone()[0]
        return r is None and -1 or int(r)

    def update_query_last_edited(self, qid):
        dt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        q = """UPDATE queries
                SET edited = ?, editor = ?
                WHERE id = ?;"""
        self.cursor.execute(q, (dt, self.user, qid))
        self.conn.commit()
        return {'message': 'Query saved', 'dt': dt}

    def add_label_for_query(self, annotconc, label):
        qid = self.conc2id(annotconc)
        if qid == -1:
            return {'error': 'Query not found'}
        maxid = self.labmaxid(qid)
        q = """INSERT INTO labels (id, qid, label, data, creator, editor, attr)
                VALUES (?, ?, ?, ?, ?, ?, ?)"""
        try:
            self.cursor.execute(q, (maxid+1, int(qid), label, "{}",
                    self.user, self.user, "{}"))
            self.conn.commit()
            r = self.update_query_last_edited(qid)
            return {'message': 'New label added', 'newid': maxid+1, 'dt': r['dt'], 'user': self.user, 'qid' :qid}
        except Exception as e:
            return {'error': 'Adding new label failed: ' + str(e)}

    def listing(self):
        # TODO: make it more general (JSON path => values)
        qid2query = {}
        for row in self.cursor.execute("SELECT id, query FROM queries").fetchall():
            qid2query[row[0]] = row[1]
        d = {"semtype": {}, "lexset": {}, "role": {}}
        if project == "pdev":
            q = """SELECT qid, label, data FROM labels
                   WHERE label != "_" AND label != "x" AND label != "u" AND label not like '%.%'"""
            for row in self.cursor.execute(q).fetchall():
                data = json.loads(unquote(row[2]))
                sd, ld, rd = {}, {}, {}
                for slot in data.get("slots", []):
                    for st in slot.get("semtype", []):
                        sd.setdefault(st, []).append((qid2query[row[0]], row[1]))
                    for ls in slot.get("lexset", []):
                        ld.setdefault(ls, []).append((qid2query[row[0]], row[1]))
                    for r in slot.get("role", []):
                        rd.setdefault(r, []).append((qid2query[row[0]], row[1]))
                for k in sd: d["semtype"].setdefault(k, []).extend(sd[k])
                for k in ld: d["lexset"].setdefault(k, []).extend(ld[k])
                for k in rd: d["role"].setdefault(k, []).extend(rd[k])
        d["semtype"] = list(d["semtype"].items())
        d["lexset"] = list(d["lexset"].items())
        d["role"] = list(d["role"].items())
        return d

    def add_label(self, qid, label):
        maxid = self.labmaxid(qid)
        # TODO: test UNIQUE constraint beforehand
        q = """INSERT INTO labels (id, qid, label, data, creator, editor, attr)
                VALUES (?, ?, ?, ?, ?, ?, ?)"""
        self.cursor.execute(q, (maxid+1, int(qid), label, "{}",
                self.user, self.user, "{}"))
        self.conn.commit()
        r = self.update_query_last_edited(qid)
        return {'message': 'New label added', 'dt': r['dt'], 'user': self.user, 'qid' :qid}

    def del_label(self, qid, lid):
        q = "DELETE FROM labels WHERE qid = ? AND id = ?"
        try:
            self.cursor.execute(q, (qid, lid))
            self.conn.commit()
            r = self.update_query_last_edited(qid)
            return {'message': 'Deleted', 'dt': r['dt'], 'user': self.user, 'qid' :qid}
        except Exception as e:
            return {'error': 'Label not deleted: ' + str(e)}

    def save_query(self, id, status="NEW", sample=0):
        dt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        q = """UPDATE queries
                SET status = ?, sample = ?, edited = ?, editor = ?
                WHERE id = ?;"""
        try:
            self.cursor.execute(q, (status, sample, dt, self.user, id))
            self.conn.commit()
        except Exception as e:
            return {'error': 'Query not saved: ' + str(e)}
        return {'message': 'Query saved', 'dt': dt, 'user': self.user, 'qid': id}

    def rename_label(self, qid, lid, label):
        q = "UPDATE labels SET label = ? WHERE qid = ? and id = ?"
        self.cursor.execute(q, (label, qid, lid))
        self.conn.commit()
        r = self.update_query_last_edited(qid)
        return {'message': 'Label renamed', 'dt': r['dt'], 'user': self.user, 'qid' :qid}

    def save_label(self, qid, lid, data, attr):
        dt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        q = """UPDATE labels
                SET data = ?, edited = ?, editor = ?, attr = ?
                WHERE qid = ? AND id = ?"""
        self.cursor.execute(q, (data, dt, self.user,
                attr, qid, lid))
        self.conn.commit()
        return {'message': 'Label saved', 'qid': qid, 'lid': lid, 'dt': dt, 'user': self.user}

    def queries(self):
        if self.conn is None:
            return {'data': [], 'message': 'DB does not exist'}
        q = """SELECT qid, label, count(*) FROM labels
                WHERE label != '_' AND label != 'x'
                    AND label != 'u' AND label NOT LIKE '%.%'
                GROUP BY qid;"""
        d = {}
        for row in self.cursor.execute(q):
            d[row[0]] = int(row[2])
        rows = []
        for row in self.cursor.execute('SELECT * FROM queries ORDER BY conc'):
            r = {}
            for i, n in enumerate(row.keys()):
                r[n] = row[i]
            rows.append(r)
        for item in rows:
            try:
                item['relsize'] = round(float(item['size']) / self.corp.size() * 1000000, 4)
            except:
                pass
            item['label_count'] = d.get(item['id'], 0)
        return {'data': rows}

    def conc2id(self, conc):
        q = 'SELECT id FROM queries WHERE conc = ?'
        try:
            return self.cursor.execute(q, (conc,)).fetchone()[0]
        except TypeError:
            return -1

    def query2id(self, query):
        q = 'SELECT id FROM queries WHERE query = ?'
        r = self.cursor.execute(q, (query,)).fetchone()
        return r and r[0] or -1

    def labels(self, conc=None, query="", qid=-1):
        if self.conn is None:
            return {'labels': [], 'message': 'DB does not exist'}
        stats = {}
        s = 0
        freqd = {}
        if conc:
            labelmap = conc.labelmap
            ids = IntVector()
            freqs = IntVector()
            conc.get_linegroup_stat(ids, freqs)
            freqd = dict(list(zip(ids, freqs)))
            s = float(sum([freqd.get(k, 0) for k in freqd if labelmap.get(k, '_') != '_']) or conc.size())
        if qid < 0:
            qid = self.query2id(query)
        q = 'SELECT * FROM labels WHERE qid = ?;'
        o = []
        for row in self.cursor.execute(q, (qid,)):
            r = {
                'freq': freqd.get(row[0], 0),
                'ratio': s and (freqd.get(row[0], 0.0)*100 / s) or 0.0
            }
            for i, n in enumerate(row.keys()):
                r[n] = row[i]
            o.append(r)
        return {'labels': sorted(o, key=lambda x: lngrp_sortstr(x["label"]))}

    def rename_labels(self, qid=-1, data=""):
        pairs = data.split('||')
        q = "UPDATE labels SET label = ? WHERE qid = ? AND id = ?"
        l = []
        lids_to_process = [int(x.split('::')[0]) for x in pairs]
        for row in self.cursor.execute("SELECT id, label FROM labels WHERE qid = ?", (int(qid),)).fetchall():
            if row[0] in lids_to_process:
                self.cursor.execute(q, (row[1] + "_BACKUP", int(qid), int(row[0])))
        for p in pairs:
            lid, nl = p.split('::')
            self.cursor.execute(q, (nl, int(qid), int(lid)))
            l.append((lid, nl))
        self.conn.commit()
        r = self.update_query_last_edited(qid)
        return {'data': l, 'dt': r['dt'], 'user': self.user, 'qid' :qid}

    def ontology(self, project="pdev"):
        if not os.path.exists(os.path.join(self._db_dir, "_onto.json")):
            return {'ontology': {}, 'error': 'Ontology not available'}
        with open(os.path.join(self._db_dir, "_onto.json")) as f:
            onto = json.loads(f.read())
            return {'ontology': onto}
        return {'ontology': {}, 'error': 'Ontology not available'}

    def set_onto(self, project="pdev", data="{}"):
        with open(os.path.join(self._db_dir, "_onto.json"), "w") as f:
            f.write(data)
            return {'message': 'Ontology was updated'}
        return {'error': 'Ontology not updated'}

    def browse_labels(self, semtype=[], position=[]):
        if type(semtype) == type(""):
            semtype = [semtype]
            position = position and [position] or [""]
        else:
            while len(position) < len(semtype):
                position.append("")
        q = """SELECT label, data, queries.conc
                FROM labels
                LEFT JOIN queries ON queries.id = labels.qid
                WHERE label != "_" AND label != "x" AND label != "u"
                ORDER BY queries.conc;"""
        ret = []
        for row in self.cursor.execute(q).fetchall():
            try:
                d = json.loads(unquote(row[1]))
            except:
                continue
            c = 0
            for s, p in zip(semtype, position):
                for slot in d.get('slots', []):
                    if not p:
                        if s and s in slot.get('semtype', []):
                            c += 1
                            break
                    else:
                        if s and s in slot.get('semtype', []) and slot["slot"] == p:
                            c += 1
                            break
            if c and c == len(semtype):
                ret.append({'query': row[2], 'label': row[0], 'c': c})
        return {'data': ret, 'semtype': semtype, 'position': position}

    def get_labelmap(self, conc):
        if self.conn is None:
            return {'error': 'DB does not exist'}
        qid = self.conc2id(conc)
        if qid < 0:
            return {'error': 'Query not found'}
        d = {}
        q = "SELECT id, label FROM labels WHERE qid = ?"
        return {int(id): label for id, label in self.cursor.execute(q, (qid,)).fetchall()}

    def download(self):
        if self.conn is None:
            return {'data': [], 'message': 'DB does not exist'}
        all_labels = {}
        actual_qid = None
        for row in self.cursor.execute('SELECT * FROM labels').fetchall():
            if row['qid'] not in all_labels:
                all_labels[row['qid']] = []
            label = {
                "freq": 0,
                "ratio": 0.0
            }
            for i, key in enumerate(row.keys()):
                label[key] = row[i]
            label['data'] = label['data'] and json.loads(unquote(label["data"])) or {}
            if self.annotation_group == "tpas" and 'slots' in label['data'] and len(label['data']['slots']):
                label['data']['pattern_string'] = self.pattern_string(label['data'])
            all_labels[row['qid']].append(label)

        ret = []
        for row in self.cursor.execute('SELECT * FROM queries ORDER BY conc').fetchall():
            query = {}
            all_query_labels = []
            if row['id'] in all_labels:
                all_query_labels = all_labels[row['id']]
            for i, key in enumerate(row.keys()):
                query[key] = row[i]
            query['label_count'] = len(list(filter(lambda o: o['label'] != '_'
                and o['label'] != 'x'
                and o['label'] != 'u'
                and ('.' not in o['label']), all_query_labels)))
            try:
                query['relsize'] = round(float(query['size']) / self.corp.size() * 1000000, 4)
            except:
                pass
            query['labels'] = sorted(all_query_labels, key=lambda o: lngrp_sortstr(o['label']))
            ret.append(query)
        return {'data': ret}

    def pattern_string(self, data):
        fslots = []
        has_subject = False
        for slot in data.get("slots", []):
            if slot.get("slot", "") == "subject":
                has_subject = True
            slot_f = slot.get('optional', False) and "(" or ""

            come = slot.get('come')
            if come == True or (isinstance(come, list) and True in come):
                slot_f = slot_f + "come "
            inter_f = ""
            opts = slot["opt"] # fix opts
            if not isinstance(opts, list):
                opts = [opts]
            sslist_f = []
            for s, r, f, o, p, l, q, pp in itertools.zip_longest(slot["semtype"], slot["role"], slot["feature"], opts,
                    slot["prep"], slot["lexset"], slot["qdm"], slot.get("prep_part", []), fillvalue=""):
                l = l.strip()
                s = s.strip()
                pp = pp.strip()
                p = p.strip()
                ls_f = "{" + q + (" " if q and l else "") + l + "}"
                ssi_f = s
                if f:
                 ssi_f = ssi_f + " : " + f
                if r:
                   ssi_f = ssi_f + " = " + r
                if s and l:
                    if p:
                        ss_f = p + " [" + ssi_f + " " + ls_f + "]"
                    elif pp:
                        ss_f = pp + " [" + ssi_f + " " + ls_f + "]"
                    else:
                        ss_f = "[" + ssi_f + " " + ls_f + "]"
                elif s:
                    if p:
                        ss_f = p + " [" + ssi_f + "]"
                    elif pp:
                        ss_f = pp + " [" + ssi_f + "]"
                    else:
                        ss_f = "[" + ssi_f + "]"
                elif l:
                    if p:
                        ss_f = p + " " + ls_f
                    elif pp:
                        ss_f = pp + " " + ls_f
                    else:
                        ss_f = ls_f
                else:
                    if p:
                        ss_f = p
                    elif pp:
                        ss_f = pp
                    else:
                        continue
                if o:
                    ss_f = "(" + ss_f + ")"
                sslist_f.append(ss_f)
            inter_f = " | ".join(sslist_f)
            infs = slot.get('inf', '')
            if infs:
                inter_f = infs + " " + inter_f
            fins = slot.get('fin', '')
            if fins:
                if infs:
                    inter_f = " | " + inter_f
                inter_f = fins + " " + inter_f
            if slot.get('slot') == "clausals" and slot.get('quote') == True:
                inter_f = " : " + inter_f
            types = slot.get('type', [])
            # TODO: remove when all types are lists
            if isinstance(types, str):
                types = [types]
            if any(types) and slot.get("slot", '') != "predic_compl":
                inter_f = '|'.join(types) + ' ' + inter_f
            slot_f += inter_f.strip()
            if slot.get('optional', False):
                slot_f += ')'
            fslots.append(slot_f + (slot["or"] and " |" or ""))
        v = data.get('verb_form', '').strip()
        if v:
            fslots.insert(has_subject and 1 or 0, v)
        fslots_str = " ".join([x for x in fslots if x])
        fslots_str = fslots_str.replace("  ", " ").replace(" ]", "]")
        return fslots_str

number_re = re.compile('[0-9]+$')

def lngrp_sortstr (lab, separator='.'):
    f = {'n': 'n%03g', 'c': 'c%s', 'x': '%s', 'y': 'y%s', 'z': 'z%s'}
    sort_str = ""
    if not lab:
        sort_str = "xx"
    else :
        parts = lab.strip().split(separator, 1)
        label = parts[0]
        rest = separator.join(parts[1:])
        if number_re.match (label):
            sort_str = f['n'] % int(label)
        else:
            if label == 'u':
                sort_str = f['y'] % label
            elif label == 'x':
                sort_str = f['y'] % label
            elif label == '_':
                sort_str = f['z'] % label
            else:
                sort_str = f['c'] % label
        if number_re.match (rest):
            sort_str = sort_str + f['n'] % int(rest)
        else:
            sort_str = sort_str + rest
    return sort_str
