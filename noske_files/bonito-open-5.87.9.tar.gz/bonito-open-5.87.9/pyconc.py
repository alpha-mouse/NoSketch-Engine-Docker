# Copyright (c) 2003-2024  Pavel Rychly, Vojtech Kovar, Milos Jakubicek
#                          Milos Husak, Vit Baisa

import manatee, os, re
from butils import escape
from cql_checker import is_full_cql

class PyConc (manatee.Concordance):
    selected_grps = []
    gdex_scores = []

    def __init__ (self, corp, action, params, sample_size=0, full_size=-1,
                  orig_corp=None):
        self.corpname = corp.get_conffile()
        self.pycorp = corp
        self.port = 0
        if action == 'q':
            # query
            manatee.Concordance.__init__ (self, corp, params, sample_size, full_size)
        elif action == 'a':
            # query with a default attribute
            default_attr, query = params.split (',', 1)
            corp.set_default_attr (default_attr)
            manatee.Concordance.__init__ (self, corp, query, sample_size, full_size)
        elif action == 'l':
            # load from a file
            manatee.Concordance.__init__ (self, corp, params)
        elif action == 's':
            # stored in _conc_dir
            manatee.Concordance.__init__(self, corp,
                    os.path.join(corp._conc_dir, params + '.conc'))
        elif action == 'w':
            # word sketch
            import wmap
            wmap.setEncoding(corp.get_conf('ENCODING'))
            if params[0] in [',', ':']:
                # seek list
                slist = wmap.StrVector (params[1:].split(','))
                self.ws = wmap.WMap (corp.get_conf('WSBASE'), corp,
                                     params[0] == ":" and 1 or 2)
                # self.* prevents freeing at the end of constructor (async conc)
                fs = self.ws.filter_poss (slist)
            elif params[0] == '-':
                # gramrel level
                self.ws = wmap.WMap (corp.get_conf('WSBASE'), corp, 1, params[1:])
                fs = self.ws.poss() # self to prevent freeing
            else:
                # only one seek
                self.ws = wmap.WMap (corp.get_conf('WSBASE'), corp, 2, params)
                fs = self.ws.poss() # self to prevent freeing (async conc)
            manatee.Concordance.__init__ (self, corp, fs)
        elif action == 't':
            import wmap
            self.ws = wmap.WMap (corp.get_conf('TERMBASE'), corp, 2, params)
            manatee.Concordance.__init__ (self, corp, self.ws.poss())
        else:
            raise RuntimeError('Unknown action')
        self.orig_corp = orig_corp or corp

    def command_g (self, options):
        # sort according to linegroups
        import annotlib
        a = annotlib.Annotation(self.pycorp, self.pycorp.annotation_group)
        annot = manatee.Concordance(self.pycorp,
                os.path.join(self.pycorp._conc_dir, options) + '.conc')
        lmap = a.get_labelmap(options)
        annot.labelmap = lmap
        self.set_linegroup_from_conc (annot)
        lmap[0] = None
        ids = manatee.IntVector(list(lmap.keys()))
        strs = manatee.StrVector(list(map(annotlib.lngrp_sortstr, list(lmap.values()))))
        self.linegroup_sort(ids, strs)

    def command_E (self, options):
        self.command_e(options)

    def command_e (self, options):
        self.sync()
        # sort first k lines using GDEX
        import gdex
        args = options.split(' ',1)
        if len(args) == 2:
            conf = args[1]
        else:
            conf = ''
        conf = self.pycorp.cm.get_gdex_conf_path(conf)
        cnt = int(args[0]) or 100
        best = gdex.GDEX(self.pycorp, conf)
        best.entryConc (self)
        score_index_toknum = best.best_k_with_toknum(cnt, cnt)
        self.gdex_scores = dict([(toknum, score) for score, index, toknum in score_index_toknum])
        self.set_sorted_view(manatee.IntVector([index for score, index, toknum in score_index_toknum]))

    def command_s (self, options):
        self.sort(options)

    def command_S (self, options):
        self.reverse ()

    def command_L (self, options):
        # filter by label
        annotname, options = options.rsplit(' ', 1)
        annot = manatee.Concordance(self.pycorp,
                os.path.join(self.pycorp._conc_dir, annotname) + '.conc')
        self.set_linegroup_from_conc (annot)
        if options[0] == '-':
            self.delete_linegroups (options[1:], True)
        else:
            self.delete_linegroups (options, False)

    def command_d (self, options):
        self.delete_lines (options)

    def command_D (self, options):
        self.delete_subparts()

    def command_F (self, options):
        self.delete_struct_repeats (options)

    def command_f (self, options):
        self.shuffle()
        
    def command_r (self, options):
        self.reduce_lines (options)
        
    def command_x (self, options):
        if options[0] == '-':
            self.switch_aligned(self.orig_corp.get_conffile())
            self.add_aligned(options[1:])
            self.switch_aligned(options[1:])
            self.corpname = options[1:]
            self.pycorp = manatee.Corpus(options[1:])
        else:
            self.swap_kwic_coll (int(options))

    def command_X (self, options):
        self.add_aligned (options)
        self.filter_aligned (options)
        
    def command_n (self, options):
        self.pn_filter (options, 0)

    def command_p (self, options):
        self.pn_filter (options, 1)

    def command_N (self, options):
        self.pn_filter (options, 0, True)

    def command_P (self, options):
        self.pn_filter (options, 1, True)

    def pn_filter (self, options, ispositive, excludekwic = False):

        lctx, rctx, rank, query = options.split (None, 3)
        if lctx.isdigit() and int(lctx) > 0: lctx = lctx + '>0'
        if rctx.isdigit() and int(rctx) < 0: rctx = rctx + '<0'
        collnum = self.numofcolls() +1

        if not is_full_cql(query):
            # filter does not support default_attr query (reason: cache not storing default_attr)
            raise Exception(f'Filter: {query} error. Only full CQL queries are supported in filtering.')

        self.pycorp.set_default_attr(self.pycorp.get_conf('DEFAULTATTR'))
        self.set_collocation (collnum, query +';', lctx, rctx, int(rank),
                              excludekwic)
        self.delete_pnfilter (collnum, ispositive)

    def xfreq_dist (self, crit, limit=1, sortkey='f', ml='', ftt_include_empty='', wlmaxfreq=0):
        words = manatee.StrVector()
        freqs = manatee.NumVector()
        norms = manatee.NumVector()
        self.pycorp.freq_dist (self.RS(), crit, limit, words, freqs, norms)
        if not len (freqs):
            return {}
        
        sumf = sum(freqs)
        sumn = self.pycorp.search_size()
        maxf = max(freqs) # because of bar height

        # TODO remove when moved to crystal
        maxn = max(norms)
        if sum(norms) <= 0:
            tofbar = float(300) / max(freqs)
            tonbar = 0
        else:
            corr = min(sumf / maxf, sumn / maxn)
            tofbar = 300 / sumf * corr
            tonbar = 300 / sumn * corr
        # / TODO remove when moved to crystal

        attrs = crit.split()
        def label (attr):
            if '/' in attr:
                attr = attr [:attr.index('/')]
            return self.pycorp.get_conf (attr + '.LABEL') or attr
        head = [{'n': label (attrs[x]), 's': x/2, 'id': attrs[x]}
                for x in range(0, len(attrs), 2)]
        head.append ({'n': 'Frequency', 's': 'frq'})

        wlmaxfreq = wlmaxfreq or maxf
        if (tonbar and not(ml)):
            maxrel = 0; # because of bar width
            for index, (f, nf) in enumerate(zip(freqs, norms)):
                if nf == 0:
                    nf = 100000
                    norms[index] = 100000

                # TODO remove when moved to crystal
                newrel = (f*tofbar / (nf*tonbar))
                if maxrel < newrel:
                    maxrel = newrel
                # / TODO remove when moved to crystal

            head.append ({'n': ('Rel [%]'), 's': 'rel'})
            lines = []
            for w,f,nf in zip (words, freqs, norms):
                if f <= wlmaxfreq:
                    line = {'Word':[{'n': '  '.join(n.split('\v'))} for n in w.split('\t')],
                            'frq': f,
                            'norm': nf}
                    # f - word frequency according to query
                    # sumf - word frequency from whole corpus
                    # nf - norm frequency - number of tokens in textype
                    # sumn - number of tokens in whole corpus
                    line['rel'] = round((float(f)/float(sumf))/(float(nf)/float(sumn))*100, 5)
                    line['reltt'] = float(f)/float(nf) * 1000000

                    # TODO remove when moved to crystal
                    line['fbar'] = int(f * tofbar) + 1
                    line['relbar'] = 1 + int(f * tofbar * 300 / (nf * tonbar * maxrel))
                    line['freqbar'] = int(15*(f+1)/(maxf+1)+1)
                    # / TODO remove when moved to crystal

                    lines.append(line)
        else:
            lines = [{'Word':[{'n': '  '.join(n.split('\v'))} for n in w.split('\t')],
                      'frq': f, 'rel': 0, 'reltt': 0, 'norm': nf,
                      # TODO remove when moved to crystal
                      'fbar': int(f * tofbar) + 1, 'relbar': 0, 'freqbar': 0,
                      # / TODO remove when moved to crystal
                      }
                     for w,f,nf in zip (words, freqs, norms) if f <= wlmaxfreq]

        if ftt_include_empty and limit == 0 and '.' in attrs[0]:
            attr = self.pycorp.get_attr(attrs[0])
            all_vals = [attr.id2str(i) for i in range(attr.id_range())]
            used_vals = [line['Word'][0]['n'] for line in lines]
            for v in all_vals:
                if v in used_vals: continue
                line = {'Word': [{'n': v}],
                        'frq': 0, 'rel': 0, 
                        'reltt': 0, 'norm': 0
                        }
                # TODO remove when moved to crystal
                line['fbar'] = 0
                line['relbar'] = 0
                line['freqbar'] = 0
                # / TODO remove when moved to crystal
                lines.append(line)

        if (sortkey.isdigit()) and (int(sortkey)<len(lines[0]['Word'])):
            sortkey = int (sortkey)
            lines = [(x['Word'][sortkey]['n'], x) for x in lines]
            lines.sort()
        else:
            if sortkey not in ('frq', 'rel'):
                sortkey = 'frq'
            lines = [(x[sortkey], x) for x in lines]
            lines.sort(key=lambda x: x[0])
            lines.reverse()

        return {'Head': head, 'total': len(lines), 'totalfrq': sum(freqs),
                'Items': [x[1] for x in lines]}


    def xdistribution (self, xrange, yrange):
        begs = manatee.IntVector (xrange)
        vals = manatee.IntVector (xrange)
        self.distribution (vals, begs, yrange)
        return list(zip(vals, begs))

    def collocs (self, cattr='-', csortfn='m', cbgrfns='mt',
                 cfromw=1, ctow=1, cminfreq=5, cminbgr=3, cmaxitems=30):
        statdesc = {'t': 'T-score',
                    'm': 'MI',
                    '3': 'MI3',
                    'l': 'log likelihood',
                    's': 'min. sensitivity',
                    'p': 'MI.log_f',
                    'r': 'relative freq.',
                    'f': 'absolute freq.',
                    'd': 'logDice',
                    }

        items=[]
        colls = manatee.CollocItems (self, cattr, csortfn, cminfreq, cminbgr,
                                     cfromw, ctow, cmaxitems)
        qfilter = '%%s%i %i 1 [%s="%%s"]' % (cfromw, ctow, cattr)
        while not colls.eos():
            items.append ({'str': colls.get_item(), 'freq': colls.get_cnt(),
                           'coll_freq' : colls.get_freq(),
                           'Stats': [{'s': '%.5f' % colls.get_bgr(s), 'n': s}
                                     for s in  cbgrfns],
                           'pfilter': qfilter % ('P',escape(colls.get_item())),
                           'nfilter': qfilter % ('N',escape(colls.get_item()))
                           })
            colls.next()
        head = [{'n': ''},
                {'n': 'Cooccurrence count', 's': 'f',
                 'style': ' style="word-wrap: break-word; width: 5em;"'},
                {'n': 'Candidate count', 's': 'F',
                 'style': ' style="word-wrap: break-word; width: 5em;"'}] \
               + [{'n': statdesc.get(s,s), 's': s} for s in cbgrfns]
        return {'Head': head, 'Items': items}

    def linegroup_info_select (self, selected_count=5):
        ids = manatee.IntVector()
        freqs = manatee.IntVector()
        self.get_linegroup_stat (ids, freqs)
        grps = [(f, i) for f,i in zip(freqs, ids) if i]
        grps.sort()
        grps = [i for f,i in grps[-5:]]
        grps.sort()
        self.selected_grps = [0] + grps
        return self.selected_grps
        
    def linegroup_info_subset (self, conc):
        #conc = manatee.Concordance (fstream)
        conc.sync()
        conc.set_linegroup_from_conc (self)
        if not conc.size():
            return 0, 0, [0]*(len(self.selected_grps)+1)
        ids = manatee.IntVector()
        freqs = manatee.IntVector()
        conc.get_linegroup_stat (ids, freqs)
        info = dict(list(zip(ids, freqs)))
        if not info:
            # no annotation
            return 0, 0, [0]*(len(self.selected_grps)+1)
        hist = [info.get(i,0) for i in self.selected_grps]
        hist.append (conc.size() - sum(hist))
        cnt, maxid = max(list(zip(freqs, ids)))
        return maxid, (cnt/float(conc.size())), hist
