version = '5.87.9'
manatee_minversion = '2.237'
