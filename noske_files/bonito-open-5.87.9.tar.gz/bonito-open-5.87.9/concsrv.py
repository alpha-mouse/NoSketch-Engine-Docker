# Copyright (c) 2014-2019  Milos Jakubicek

import socket, sys, re, manatee, time
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import unquote
from http.client import HTTPConnection, HTTPResponse
from pyconc import PyConc

server_host = 'localhost'

class ConcRequestHandler (BaseHTTPRequestHandler):

    def do_GET (self):
        if "?" in self.path:
            command, params = self.path[1:].split("?")
        else:
            command, params = self.path[1:], None
        q = {}
        if params:
            params = re.split ('[;&]', params)
            for p in params:
                p = p.split("=")
                if len(p) > 1:
                    q[p[0]] = unquote(p[1])
                else:
                    q[p[0]] = ""
        if not hasattr (self, command):
            self.send_error (404)
            return
        getattr (self, command) (**q)

    def conc_info (self):
        concsize = finished = fullsize = 0
        if self.server.conc:
            finished = self.server.conc.finished()
            concsize = self.server.conc.size()
            fullsize = self.server.conc.fullsize()
        self.send_response (200)
        self.end_headers()
        self.wfile.write ("%d\n%d\n%d\n" % (finished, concsize, fullsize))

    def send_conc (self, minsize=None):
        csize = self.server.conc.size()
        conc = self.server.conc
        if not conc:
            self.send_error (404, "Not yet started")
            return
        minsize = int(minsize)
        if minsize == -1 and not conc.finished():
            self.send_error (404, "Not yet finished")
            return
        if csize < minsize:
            self.send_error (404, "Only %d items available" % csize)
            return
        self.send_response (200, "Sending %d items" % csize)
        self.send_header('Content-type', 'application/octet-stream')
        self.end_headers()
        conc.save (self.wfile.fileno(), False, True) # partial
        
class ConcServer (HTTPServer):

    def __init__(self, logfile):
        HTTPServer.__init__ (self, (server_host, 0), ConcRequestHandler)
        self.conc = None
        self.logfile = open(logfile.encode("utf-8"), "w", 1) # unbuffered => always flush (after every line)
        sys.stderr = self.logfile
        self.logfile.write("Started\n")
    
def get_server_conc_sizes (server_port):
    conn = HTTPConnection (server_host, server_port, timeout=60)
    conn.request ("GET", "/conc_info")
    response = conn.getresponse()
    return list(map(int, response.read().split("\n")[:3]))

# Python 3 HTTPResponse always wraps the socket in a buffered file object,
# this ugly hack replaces the file object inside the HTTPResponse with an
# unbuffered one. We're accessing the socket directly, but the buffering
# consumes bytes from it, rendering them inaccessible.
#
# Introduced in https://github.com/python/cpython/commit/7e11b3f52247f0a0fd8be8879873a74d4ec02b38
class myHTTPResponse(HTTPResponse):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fp = args[0].makefile('rb', 0)

def get_server_conc (corp, server_port, minsize):
    sleeptime = 1
    conn = HTTPConnection (server_host, server_port, timeout=60.)
    conn.response_class = myHTTPResponse
    while True:
        conn.request ("GET", "/send_conc?minsize=%d" % minsize)
        conn.sock.setblocking(True)
        response = conn.getresponse()
        if response.status == 200:
            fileno = response.fileno()
            conc = PyConc (corp, 'l', fileno)
            conc.port = server_port
            return conc
        elif response.status != 404: # less than minsize
            raise Exception ("Concordance failed")
        response.read() # flush
        time.sleep(sleeptime * 0.1)
        sleeptime += 1

