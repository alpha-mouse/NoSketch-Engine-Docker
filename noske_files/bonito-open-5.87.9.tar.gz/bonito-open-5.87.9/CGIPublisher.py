# Copyright (c) 2003-2019  Pavel Rychly, Vojtech Kovar, Milos Jakubicek, Vit Baisa

import os, sys, cgi
from types import MethodType
from inspect import isclass
import codecs
import version
from urllib.parse import urlencode, quote_plus
from urllib.parse import parse_qs
import json
import time
from exportlib import export
from manatee import version as manatee_version

def replace_dot_error_handler (err):
    return '.', err.end

codecs.register_error ('replacedot', replace_dot_error_handler)

def function_defaults (fun):
    defs = {}
    if isclass (fun):
        fun = fun.__init__
    try:
        dl = fun.__defaults__ or ()
    except AttributeError:
        return {}
    nl = fun.__code__.co_varnames
    for a,v in zip (nl [fun.__code__.co_argcount - len(dl):], dl):
        defs [a] = v
    return defs

def correct_types (args, defaults, del_nondef=0, selector=0, safe=1):
    corr_func = {type(0): int, type(0.0): float, list: lambda x: [x]}
    for full_k, v in list(args.items()):
        if selector:
            k = full_k.split(':')[-1] # filter out selector
        else:
            k = full_k
        if (safe and k.startswith('_')) \
                                or type (defaults.get (k,None)) is MethodType:
            del args[full_k]
        elif k in defaults:
            default_type = type (defaults[k])
            if default_type is not list and type(v) is list:
                args[k] = v = v[-1]
            if type(v) is not default_type:
                try:
                    args[full_k] = corr_func[default_type](v)
                except: pass
        else:
            if del_nondef:
                del args[full_k]
    return args

def choose_selector (args, selector):
    selector += ':'
    s = len (selector)
    for n,v in [(n[s:],v) for n,v in list(args.items()) if n.startswith (selector)]:
        args [n] = v


class CGIPublisher:
    _headers = {'Content-Type': 'application/json; charset=utf-8'}
    _keep_blank_values = 0
    _tmp_dir = '/tmp'
    _url_parameters = []
    _request_method = 'GET'
    _allowed_sse_methods = ["jobproxy", "freqdist"]
    debug = ''
    _debugcode = '1'
    format = 'json'
    export_formats = ['csv', 'tsv', 'xml', 'tbx', 'tmx', 'xlsx', 'txt']
    reload = 0
    _anonymous = 0
    _linesep = 'Win' in os.getenv('HTTP_USER_AGENT', '') and '\r\n' or '\n'
    _safe_corpnames = False
    _version = version.version

    def __init__ (self):
        self.defaults = self.clone_self()
        self._request_method = os.environ['REQUEST_METHOD']

    def _setup_user(self):
        pass

    def self_encoding(self):
        return 'utf-8'

    def _set_defaults (self):
        pass

    def call_method (self, method, args, named_args):
        na = named_args.copy()
        correct_types (na, function_defaults (method), 1, safe=0)
        return method(*args[1:], **na)

    def call_function (self, func, args, **named_args):
        na = self.clone_self(safe=0)
        na.update (named_args)
        correct_types (na, function_defaults (func), 1, safe=0)
        return func(*args, **na)

    def clone_self (self, safe=1):
        na = {}
        for a in dir(self) + dir(self.__class__):
            if (not a.startswith('_') or not safe) \
                    and not callable (getattr (self, a)):
                na[a] = getattr (self, a)
        return na

    def parse_parameters (self, selectorname=None,
                          environ=os.environ, post_fp=None):
        self.environ = environ
        named_args = {}
        form = cgi.FieldStorage(keep_blank_values=self._keep_blank_values,
                                environ=self.environ, fp=post_fp)
        self._setup_user()
        if 'json' in form:
            json_data = json.loads(form.getvalue('json'))
            named_args.update(json_data)
        for k in list(form.keys()):
            self._url_parameters.append(k)
            # must remove empty values, this should be achieved by
            # keep_blank_values=0, but it does not work for POST requests
            if len(form.getvalue(k)) > 0 and not self._keep_blank_values:
                named_args[str(k)] = self.recode_input(form.getvalue(k))
            if k == 'attachment':
                named_args[str(k)] = (form[k].filename, form[k].file)
        if self._safe_corpnames:
            url_args = parse_qs(self.environ['QUERY_STRING'])
            for key in ('corpname', 'ref_corpname', 'bim_corpname'):
                if key in self.__dict__:
                    del(self.__dict__[key])
                if key not in named_args:
                    continue
                if key not in url_args:
                    raise Exception(f'{key} missing from URL query')
                if type(named_args[key]) is list and len(set(named_args[key])) > 1:
                    raise Exception(f'{key} value mismatch')
        na = named_args.copy()
        correct_types (na, self.clone_self())
        if selectorname:
            choose_selector (self.__dict__, getattr (self, selectorname))
        self.__dict__.update (na)
        if "instantSubCorp" in named_args:
            named_args["create"] = True
            self.subcpath[-1] = os.path.dirname(self.subcpath[-1].rstrip("/")) + "/###INSTANT###"
            if "ttq" not in named_args:
                named_args["ttq"] = self._texttype_query()
            self.subcname = "###%s###" % str(hash(named_args["ttq"])).replace("-","M")
            named_args["subcname"] = self.subcname
            ret = self.call_method(getattr(self, "subcorp"), (), named_args)
            self.subcname = ret["subcorp"].split(":", 1)[1] # may have changed if it has already existed
            named_args["subcname"] = self.subcname # ^^^
            self.usesubcorp = self.subcname
            named_args["usesubcorp"] = self.subcname
        return named_args

    def default(self):
        return {}

    def run_unprotected (self, path=None, selectorname=None, outf=sys.stdout):
        if os.environ['REQUEST_METHOD'] == 'OPTIONS':
            sys.stdout.write('Content-Type: text/plain; charset=utf-8\n')
            sys.stdout.write('Status: 200\n\n')
        else:
            if path is None:
                path = os.getenv('PATH_INFO','').strip().split('/')[1:]
            if len(path) == 0 or path[0] == '':
                path = ['default']
            else:
                if path[0].startswith ('_'):
                    self.output_headers()
                    self.output_result(path[0], {'error': 'Access denied'})
                    return
            try:
                named_args = self.parse_parameters (selectorname)
            except Exception as e:
                self.output_headers()
                if self.debug == self._debugcode:
                    import traceback
                    msg = traceback.format_exc()
                else:
                    msg = str(e)
                self.output_result(path[0],
                        {'error': self.rec_recode(msg, 'utf-8', 1)})
                return
            if "sse" in named_args: # server-side event: keep sending results until stdout is closed
                if path[0] not in self._allowed_sse_methods:
                    raise Exception("Method '%s' not allowed as SSE" % path[0])
                outf.write("Cache-Control: no-cache\n")
                outf.write("Content-Type: text/event-stream\n\n")

                if path[0] in ['freqdist']: # SSE call printing directly to stdout from generator
                    method = getattr (self, path[0])
                    na = named_args.copy()
                    correct_types (na, function_defaults (method), 1, safe=0)

                    for result in method(*path[1:], **na):
                        outf.write("data: ")
                        outf.write(json.dumps(result))
                        outf.write("\n\n")
                        outf.flush()
                    outf.write('data: {"finish": 1}\n\n')
                else:
                    retry = 1
                    while True:
                        methodname, result = self.process_method(path[0], path, named_args)
                        outf.write("data: ")
                        self.output_result(methodname, result, outf, named_args)
                        outf.write("\n\n")
                        time.sleep(retry)
                        if retry < 15:
                            retry += 1
            else:
                methodname, result = self.process_method(path[0], path, named_args)
                self.output_headers(methodname=path[0], params=named_args)
                self.output_result(methodname, result, outf, named_args)

    def process_method (self, methodname, pos_args, named_args):
        if not hasattr (self, methodname):
            return (methodname, {'error': 'Unknown method'})
        method = getattr (self, methodname)
        try:
            return (methodname, self.call_method(method, pos_args, named_args))
        except Exception as e:
            if self.debug == self._debugcode:
                print('\n\n')
                raise
            return (methodname, {'error': self.rec_recode(str(e), 'utf-8', 1)})

    def recode_input(self, x, decode=1):
        if type(x) is list:
            return [self.recode_input(v, decode) for v in x]
        return x.strip()

    def rec_recode(self, x, enc='', utf8_out=False):
        if not utf8_out: return x
        if not enc: enc = self.self_encoding()
        if isinstance(x, tuple) or isinstance(x, list):
            return [self.rec_recode(e, enc, utf8_out) for e in x]
        if isinstance(x, dict):
            d = {}
            for key, value in x.items():
                if key in ['corp_full_name', 'Corplist']: d[key] = value
                else: d[key] = self.rec_recode(value, enc, utf8_out)
            return d
        elif type(x) is str:
            return x
        return x

    def urlencode (self, key_val_pairs):
        """recode values of key-value pairs and run urlencode from urllib"""
        enc = self.self_encoding()
        if type(key_val_pairs) is str:
            # mapping strings
            return quote_plus(key_val_pairs)
        return urlencode ([(k, self.rec_recode(v, enc, utf8_out=True))
                                                for (k,v) in key_val_pairs])

    def output_headers(self, outf=sys.stdout, methodname="", params={}):
        if methodname == 'fcs': # Default output format for FCS is XML
            self.format = 'xml'
        self._headers['Content-Type'] = {
            'csv': 'application/csv; charset=utf-8',
            'tsv': 'application/csv; charset=utf-8',
            'tbx': 'application/xml; charset=utf-8',
            'tmx': 'application/xml; charset=utf-8',
            'xlsx': 'application/vnd.ms-excel',
            'xml': 'application/xml; charset=utf-8',
            'txt': 'text/plain; charset=utf-8',
            'json': 'application/json; charset=utf-8'}\
            .get(self.format, 'text/plain; charset=utf-8')
        if self.format in self.export_formats and\
                'Content-Disposition' not in self._headers:
            self._headers['Content-Disposition'] =\
                    'attachment; filename="%s"' % self.get_file_name(methodname, params)
        if outf:
            for k,v in list(self._headers.items()):
                outf.write('%s: %s\n' % (k, v))
            outf.write('\n')
            outf.flush()
        return self._headers

    def get_file_name(self, method="sketch_engine", params={}):
        if method == "wsketch":
            method = "word_sketch"
        elif (method == "wordlist" and self.wlattr == "WSCOLLOC")\
            or (method == "extract_keywords" and params.get('attr', '') == "WSCOLLOC"):
            method = "word_sketch_as_list"
        elif method == "wsdiff":
            method = "word_sketch_difference"
        elif method == "thes":
            method = "thesaurus"
        elif method in ["freqs", "freqml"]:
            method = "frequency"
        elif method == "collx":
            method = "collocations"
        elif method == "concordance" and self.concordance_query and self.concordance_query[0].get('sel_aligned'):
            method = "parallel_concordance"
        elif method in ["wordlist", "extract_keywords"] and self.usengrams:
            method = "ngrams"
        elif method == "extract_keywords" and params.get('attr', '') == "TERM":
            method = "terms"
        elif method == "extract_keywords":
            method = "keywords"

        return '%s_%s_%s.%s' % \
                (method, params.get('corpname', 'corpus').replace("/", "_"),
                time.strftime('%Y%m%d%H%M%S'), self.format)

    def output_result(self, methodname, result, outf=sys.stdout, named_args={}):
        if isinstance(result, str):
            outf = codecs.getwriter("utf-8")(outf)
            outf.write(result)
        else:
            result['api_version'] = self._version
            result['manatee_version'] = manatee_version()
            params = {k:v for k, v in named_args.items()\
                    if not k.startswith('_')}
            export(self, methodname, result, self.format, outf, self._linesep, params)
